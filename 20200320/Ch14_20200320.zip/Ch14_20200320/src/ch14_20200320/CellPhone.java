/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch14_20200320;

/**
 *
 * @author xvpow
 */
public interface CellPhone {
    public void callout(String number);
    public void wifi();
     //java 8開始 可使用defaul介面方法
    public default void testWifi(){
	wifi();
    }
    //java 8開始 介面 可使用static方法
    //工廠模式
    public static CellPhone newCellPhone(String type){
	CellPhone cp = null;
	switch(type){
	    case "android":
		return new AndroidPhone();
	    case "iphone":
		return new IPhone();
	    default:
              throw new IllegalArgumentException();
	}
    }
}
