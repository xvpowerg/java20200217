/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch14_20200320;

/**
 *
 * @author xvpow
 */
public class Ch14_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
	CellPhone phone = CellPhone.newCellPhone("iphone");
	phone.callout("8825522");
	phone.testWifi();
	phone.wifi();
    }
    
}
