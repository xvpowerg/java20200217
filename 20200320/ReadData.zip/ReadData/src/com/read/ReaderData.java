/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.read;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.Files;
import java.io.IOException;
import java.util.List;

public abstract class ReaderData {
    private String[] read()throws IOException {
    Path ph = Paths.get("C:", "mydir","Data.txt");
	   List<String> list = Files.readAllLines(ph);
	   String[] tmp = new String[list.size()];
	return list.toArray(tmp);	
    }
    protected abstract void dataStyle(String[] datas);
    public void exportData()throws IOException{
	String[] datas = read();
	dataStyle(datas);
    }     
}
