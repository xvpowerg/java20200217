/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch16_20200325;

/**
 *
 * @author xvpow
 */
public class Ch16_4 {

    static String fetchString(Filter f,String[] array){
	String tmp = "";
	for (String v : array){
	    if (f.doFilter(v)) tmp += v+" ";
	}
	return tmp;
    }
    public static void main(String[] args) {
	String[] data1 = {"12345","12","1234567","123","123456789"};
    String st1 = fetchString(new Filter(){
	    public boolean doFilter(String v){
		return v.length() >= 5;
	    }
	},data1);
    System.out.println(st1);
	
    String st2 = fetchString(s->s.length() > 5,data1);
     System.out.println(st2);
     
       String st3 = fetchString(s->{
	    //s.toUpperCase()
	   return s.length() > 5;},data1);
       //傳入的參數1個以上 必須加上小誇號
       Calculate c1 = (n1,n2)->n1.intValue() + n2.intValue();
       
       //作業 可計算有浮點數的加減乘除 使用Calculate 介面
       
    }
    
}
