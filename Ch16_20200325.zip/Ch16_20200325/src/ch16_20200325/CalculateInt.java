/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch16_20200325;

/**
 *
 * @author xvpow
 */
public class CalculateInt {
    private String discript = "計算!!!";
    //非靜態內部類 //限制靜態方法無法直接呼叫
    private class PluseInt implements Calculate{
	public Integer calcu(Number n1,Number n2){
	    System.out.println(discript);
	    return n1.intValue() + n2.intValue();
	}
    }
    //測試非靜態內部類可new
    void test1(){
	Calculate calcu = new PluseInt();
    }
    
    //靜態內部類 //限制他無法呼叫非靜態的
    private static class MinusInt implements Calculate{
	private Number def1 , def2;
         MinusInt(Number n1,Number n2){
	    this.def1 = n1;
	    this.def2 = n2;
	}
	public Number calcu(Number n1,Number n2){
	       //System.out.println(discript);//因為discript 不是靜態的所以無法呼叫
	    //假設n1 或 n2 小於0 數值就改為預設
	    n1 = n1==null || n1.intValue() < 0 ? def1: n1;
	    n2 = n2==null || n2.intValue() < 0 ? def2: n2;
	    
	    return n1.intValue() - n2.intValue();
	}	 
    }
    

   public static Number calculation(int i1,int i2,String action){
       Calculate calcu = null;
       int count = 0;
	switch(action){
	    case "+":
		//不能直接new 因為PluseInt 是非靜態的
		CalculateInt cint = new CalculateInt();
		calcu = cint.new PluseInt();
	        break;	
	    case "-":
		calcu = new MinusInt(5,2);
		break;
           case "*":
	           //匿名內部類 //限制 使用區域變數時必須是final
	       calcu = new Calculate(){
		   public Number calcu(Number n1,Number n2){
		    //因為count是final 不能重新給予數值
		    //count = 0;
		       return n1.intValue() * n2.intValue();
		   }
	       };
	         break;	
           case "/":
	      //lambda //限制 使用區域變數時必須是final 只能用在介面 介面必須是 FunctionalInterfacepublic
		calcu = (n1,n2)->n1.intValue() / n2.intValue();
		break;		       
	}
	return calcu.calcu(i1, i2);
   }
}
