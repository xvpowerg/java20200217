/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch16_20200325;

/**
 *
 * @author xvpow
 */
public class PluseInt  implements Calculate{
    @Override
    public Integer calcu(Number n1, Number n2) {
	   return  n1.intValue() + n2.intValue();
    }
}
