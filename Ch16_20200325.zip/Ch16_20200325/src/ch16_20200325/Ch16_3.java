/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch16_20200325;

/**
 *
 * @author xvpow
 */
public class Ch16_3 {

    public static void main(String[] args) {
	Dog dog1 = new Dog();
	dog1.bark();
	Dog dog2 = new Dog(){
	   public void bark(){
	       System.out.println("喵喵!!");
	   }
	};
	dog2.bark();
    }
    
}
