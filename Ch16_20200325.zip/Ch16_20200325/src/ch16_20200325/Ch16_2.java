/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch16_20200325;

/**
 *
 * @author xvpow
 */
public class Ch16_2 {

    public static void main(String[] args) {
	//Number n1 = CalculateInt.calculation(20, 70, "+");
	//System.out.println(n1);
//	Number n2 = CalculateInt.calculation(23, 5, "-");
//	System.out.println(n2);
	
//       Number n3 = CalculateInt.calculation(2, 5, "*");
//	System.out.println(n3);
	    Number n4 = CalculateInt.calculation(16, 2, "/");
	    System.out.println(n4);
    }
    
}
