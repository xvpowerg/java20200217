/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch16_20200325;

public class Ch16_1 {
    
    public static void main(String[] args) {
	Calculate c1 = new PluseInt();
	Number value = c1.calcu(20, 50);	
	System.out.println(value.intValue());
    }
    
}
