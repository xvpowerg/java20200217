/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch1_20200217;

/**
 *
 * @author xvpow
 */
public class Ch1_2 {
    public static void main(String[] args){
	  
	//變數宣告
	//變數名稱不可用keyword
	//變數名稱 開頭可以是 英文字母 _ $
	//變數名稱 第二個開始可以是 英文字母 _ $ 數字
	int ___$$$ = 10;
	int $1234 = 75;
	int _abc = 31;
	//底線口訣:底線的前後必須是底線或數字
	int v1 = 12_345;
	int v2 = 12___345;
	//二進位 0b
	int binary = 0b10011011;
	System.out.println(binary);
	//8進位 0
	int oct = 0233;
	System.out.println(oct);
	//16進位 0x  A=10 B= 11 C = 12 D = 13 E = 14 F = 15 
	int hex = 0x9B;
	System.out.println(hex);
	
     //特別正確案例
       int oct2 = 0__233;
      System.out.println(oct2);
     //以下錯誤
     //int hex2 = 0x_9_B;
    // int binary2 = 0_b10011011;
     //float f2 = 2._56_71f;
    }
}
