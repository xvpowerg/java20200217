/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch1_20200217;

/**
 *
 * @author xvpow
 */
public class Ch1_1 {
    public static void main(String[] args) {
	    //複習 先修
	    //變數 注意重點 名稱大小寫有別  不可重複宣告 名稱不可定義為keyword
	    //以下為基本型態(primitive)
	    //變數核心概念
	    //整數
	    
	    //byte 8bit -128~127
	    //short 16bit -32768 ~ 32767
	    //int 32bit 預設(default)
	    //long 64bit 在整數中最大
	    
	    byte b1 = 127;
	    long value = 2147483648L;
	    //浮點數
	    //float 32bit 
	     float pi = 3.1415f;
	    //double 64bit 預設(default)
	    //字元
	    //字串當中的每一個元素就是字元
	    //16bit
	    //字元可存放數字範圍0~65535
	    //"不可存負數"
	    //字元來說 數字 < 大寫英文 < 小寫英文
	    char c1 = '9';
	    char c2 = 'Z';
	    char c3 = 'z';
	     
	    int v1 = c1;
	    int v2 = c2;
	    int v3 = c3;
	    
	    System.out.println(v1);
	    System.out.println(v2);
	    System.out.println(v3);
	 
	    //布林 表示true 或 false
	    boolean isOpen = true;
	    //所有不是基本型態的都是參考型態(reference)
	    //字串
	    String name = "Join"; 
	    
	    
	
	
	
    }
    
}
