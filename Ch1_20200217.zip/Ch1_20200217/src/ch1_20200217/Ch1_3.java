/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch1_20200217;

/**
 *
 * @author xvpow
 */
public class Ch1_3 {
    public static void main(String[] args){
	//運算子 + - * /
	//也是先* / 後 + -
	int value1 = 8 + 2 * 3 / 2;
	System.out.println(value1);
	
	//整數除整數還是整數 取商的感覺	
	int v2 = 9 / 2;
	System.out.println(v2);
	int mod = 9 % 2;
	System.out.println(mod);
	//如果算式當中有小數點 產出 就是浮點數類型
	float v3 = 9 / 2.0f;
	System.out.println(v3);
	
	//被除數如何變動 餘數一定不會超過除數
	int time = 0;
	int count= 4;
	System.out.println("===========================");
	System.out.println(time % count);
	time = 1;
	System.out.println(time % count);
	time = 2;
	System.out.println(time % count);
	time = 3;
	System.out.println(time % count);
	time = 4;
	System.out.println(time % count);
	time = 5;
	System.out.println(time % count);
	
    }
}
