/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20200302;

/**
 *
 * @author xvpow
 */
public class Ch6_5 {

    static void testRecursive(int i){
	System.out.println("Index:"+i);
	if (i < 3){
	  testRecursive(i + 1);
	}
	System.out.println("End:"+i);
    }
    
    public static void main(String[] args) {
	testRecursive(1);
	
    }
    
    //作業 1 宣告一個方法 可以傳入 2各整數 幫回傳最大值
    //作業 2 宣告一個方法 可以傳入1個整數陣列 幫我回傳最小值
    
}
