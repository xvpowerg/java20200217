/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20200302;

/**
 *
 * @author xvpow
 */
public class Ch6_1 {

    public static void main(String[] args) {
	
//	for (int ri = 0; ri <array2x3.length ;ri++){
//	    for (int ci = 0;ci <array2x3[ri].length;ci++){
//		System.out.print(array2x3[ri][ci]+" ");
//	    }
//	    System.out.println();
//	}
	
      /**/
       //2 宣告一個長度為20的陣列 幫我把20個陣列內容填滿，
       //內容是1~100中的偶數 如果超過陣列數就不存
       int[] array = new int[20];//index 0~19
       int k = 0;
       for (int i= 1; i <=100;i++){
	   if (k <array.length && i % 2 == 0) 
	       array[k++] = i;
      }
       
       for (int v : array){
	   System.out.println(v);
       }
       

    }
    
}
