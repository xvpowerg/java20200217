/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20200302;

/**
 *
 * @author xvpow
 */
public class Ch6_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
	//左[] 加總等於右邊就對
	int[][] array1 = new int[2][3];//java 愛
	int[] array2[] = new int[2][3];
	int array3[][] = new int[2][3];
	//右邊的變化
	int[][] array4 = new int[2][]; //不規則型多維陣列宣告方式 
	int[][] array5 = {{1,5,6},
			  {1,8,9,10,11,18}   }; 
	int[][] array6 = new int[][]{{9,3,5},
				    {7,3,2,6}   };
	int[][] array7 = new int[2][];
	array7[0] = new int[3];
	array7[1] = new int[]{1,8,6,1};
	
	
	
    }
    
}
