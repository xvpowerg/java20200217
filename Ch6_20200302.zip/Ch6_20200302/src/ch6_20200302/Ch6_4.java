/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20200302;

/**
 *
 * @author xvpow
 */
public class Ch6_4 {
    //static 只能呼叫static的
    
    //方法必要元素
    //1 回傳值 void 無回傳 
    //2 方法名稱
    //3 傳入參數 () 表示沒參數
    //4 方法本體 {}
    static  void  test1(){
	System.out.println("test1 Method");
	
    }
   
    //有回傳值一定return
    static int test2(int a1,int b2){
	int ans = a1 + b2;
	return ans;//可以回傳一個數值 並離開方法
    }
    
    //在方法內的區域變數都會放在Stack
    public static void main(String[] args) {
	/*int x = 905;
	int y = 9;
	test1();
	int v1 = test2(2,6);
	System.out.println(v1);*/
	
    }
    
}
