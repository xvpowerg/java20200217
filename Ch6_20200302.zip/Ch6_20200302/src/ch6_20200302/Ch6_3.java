/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20200302;

/**
 *
 * @author xvpow
 */
public class Ch6_3 {


    public static void main(String[] args) {
	
	int[][] array2xn = {{4,6,8},{9,15}};
	System.out.println(array2xn[1][1]);
	
	int[][][] array3 = {
	    { {8,9,3},{11,17,5,18},{93,65}   },
	    { {25,37}}
	};
	System.out.println(array3[0][1][1]);
	
	int[][][] array4 = new int[3][][];
	array4[0] = new int[][]{ {7,5,2},{8,4}};
	array4[2] = new int[][]{ {1},{53,81,94}};
	
	 System.out.println(array4[0][1][2]);
	//System.out.println(array4[2][0][1]);
	//System.out.println(array4[1][0][0]);//	
	System.out.println(array4[1][0][0]);
	
    }
    
}
