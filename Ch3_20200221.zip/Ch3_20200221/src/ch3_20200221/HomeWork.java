/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch3_20200221;

/**
 *
 * @author xvpow
 */
public class HomeWork {
    //宣告兩變數
    //宣告一個動作
    char action = '+';
    //如果動作是+ 宣告的兩數相加
    //如果動作是- 宣告的兩數相減
    //如果動作是* 宣告的兩數相乘
    //如果動作是/ 宣告的兩數相除
    //結果幫我顯示一下:
}
