/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch3_20200221;

/**
 *
 * @author xvpow
 */
public class Ch3_2 {
    public static void main(String[] args){
	//if (條件){
	   //命令
         //}
	 //常考
	int age = 12;
	//如果if 沒加上{}時可控制範圍　只有最接近　if 的那一段命令
	if (age >= 18) System.out.println("成年");
	else System.out.println("未成年");	  
//以下產生錯誤因為if 沒有加上{}但是有兩條命令	  
//	  if (age >= 18)
//	  System.out.println("成年");
//	  System.out.println("好棒棒!!");
//	  else{
//		  
//	}
//判斷式多 if () else if() ...else  
	
	  int action = 8;
	  if (action == 1){
	      System.out.println("開啟Filfe");
	  }else if(action == 2)
	       System.out.println("開啟Edit");
	   else if(action == 3){
	       System.out.println("開啟View");
	  }else
	      System.out.println("無!");
	   
	
	  //三元運算子　(優先子很低！)
	  
	  int score = 12;
	  if (score >= 60){
	      System.out.println("及格");
	  }else{
	      System.out.println("不及格"); 
	  }
	  //三元運算子
	  String msg = score >= 60? "及格":"不及格";
	 System.out.println(msg);
	 
	 //使用三元運算子對v取絕對值
	 int v = -5;
	 int ans = 7 + (v < 0 ? -v: v);
	 System.out.println(ans);

    }
}
