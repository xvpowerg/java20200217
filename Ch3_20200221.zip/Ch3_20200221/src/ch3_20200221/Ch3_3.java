/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch3_20200221;
import java.time.LocalDate;

public class Ch3_3 {
    //switch case 必考！
    public static void main(String[] args){
	//switch 的參數　可以是 byte short int char String enum    
	//int action = 1;
//	  if (action == 1){
//	      System.out.println("開啟Filfe");
//	  }else if(action == 2)
//	       System.out.println("開啟Edit");
//	   else if(action == 3){
//	       System.out.println("開啟View");
//	  }else
//	      System.out.println("無!");

//	int action = 1;
//	switch(action){
//	    case 1:
//		//下達命令 
//		//碰到break就結束目前的switch
//		System.out.println("開啟File");
//		break;
//	    case 2:
//		System.out.println("開啟Edit");
//	       break;	
//	    case 3:
//		System.out.println("開啟View");
//		break;
//	    default:
//		System.out.println("無!");
//	       break;
//	}

//考試會考
//	int action = 2;
//	switch(action){
//	    case 1:
//		System.out.println("開啟File");
//		break;
//	    case 2:
//		System.out.println("開啟Edit");
//	    case 3:
//		System.out.println("開啟View");
//		break;
//	    default:
//		System.out.println("無!");
//	       break;
//	}
		/*
春 3 4 5
夏: 6,7,8
秋 9 10 11
冬:1  2  12
*/
		
	
	int month = LocalDate.now().getMonthValue();//可取得目前電腦月份	
	switch(month){
	    case 3:
	    case 4:
	    case 5:
	System.out.println("春");
            break;
	    case 6:
	    case 7:
	    case 8:
	System.out.println("夏");
            break;	
	    case 9:
	    case 10:
	    case 11:
	System.out.println("秋");
	    break;
	   case 1:
	    case 2:
	    case 12:  
	System.out.println("冬");
            break;
	  default:
	System.out.println("Error!");      
	    break;	
	}
		

    }
    
}
