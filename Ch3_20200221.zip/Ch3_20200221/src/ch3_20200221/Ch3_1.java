/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch3_20200221;

/**
 *
 * @author xvpow
 */
public class Ch3_1 {

    public static void main(String[] args) {
	int i =0;
	boolean x = false & ++i <5;//無短路現象
	System.out.println(i);//1
	x = true | ++i < 5;
	System.out.println(i);//2
	System.out.println(x);
	//& | ^ 算數學用的
	
	 int n1 = 0b1011_1100_0011_1110;//48190 //A 公司
	 int n2 = 0b0001_0110_0101_0110;//5718 //B 公司
	 
	 //&        0001 0100 0001 0110‬ //過濾
	 //|        ‭1011 1110 0111 1110‬ //融合效果
	 //^	    1010 1010 0110 1000 //取得各自擁有的
	 
	 int publicKey = 43624;
	 int akey = n2 ^ publicKey;//可由publicKey 與 B公司作互斥推算出 A公司的金鑰
	 System.out.println(akey);
	 //利用互斥 算出公開金鑰 43624
	 int ans = n1 & n2;
	 System.out.println("&"+ans);
	 ans = n1 | n2;
	 System.out.println("|"+ans);
	 ans = n1 ^ n2; 
	 System.out.println("^"+ans);
	
    }
    
}
