/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch3_20200221;

/**
 *
 * @author xvpow
 */
public class Ch3_5 {
    public static void main(String[] args){
	//考試重點2
	//數字加_
	
//	int n = 123_456;
// 　　　switch(action){
//	     case 123456:
//		 System.out.println("A");
//		 break;
//	     case 123_456:
//		 System.out.println("B");
//		 break; 
//	    case 12:
//		 System.out.println("C");                                    
//		 break;
//  	     default:
//               System.out.println("Error!");                                     
//           break;
//　　　　　 }

//1 A
//2 B
//3 C
//4 Eroor
//5 以上皆否　會編譯錯誤　因為case 的數值有重複的
	
	
    }
}
