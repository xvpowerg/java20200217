/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch3_20200221;

/**
 *
 * @author xvpow
 */
public class Ch3_4 {
     public static void main(String[] args){
	 //考試重點
	 //1 case 後的數值 必須是常數
	 //常數習慣寫全大寫
	 final int PLAY = 1;
	 final int PAUSE = 2;
	 final int STOP = 3;
	 int action = PAUSE;

	 switch(action){
	     case PLAY:
		 System.out.println("Play");
		 break;
	     case PAUSE:
		 System.out.println("Pause");
		 break; 
	    case STOP:
		 System.out.println("Pause");                                    
		 break;  
	 }
	 
	 
     }	 
}