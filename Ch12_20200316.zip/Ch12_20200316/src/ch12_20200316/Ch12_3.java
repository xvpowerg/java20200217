/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_20200316;

/**
 *
 * @author xvpow
 */
public class Ch12_3 {

    //ToString
    public static void main(String[] args) {
	Student st1 = new Student("Vivin",27);
	System.out.println(st1);
	String stValue = "Info:"+st1;//自動呼叫toString
	System.out.println(stValue);
	
    }
    
}
