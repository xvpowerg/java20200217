/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_20200316;

/**
 *
 * @author xvpow
 */
public class Apartment {
    //因為靜態的資源共享
   static int taiwanCount = 0;
    int count;
    String address = "";
    int old;
   public static Apartment create(){
       return new Apartment();
   }
    public String toString(){
	return address+":"+count+
		":"+old+":"+taiwanCount;
    }
}
