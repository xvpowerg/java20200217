/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_20200316;

/**
 *
 * @author xvpow
 */
public class Student {
     String name;
    int age; 
    Student( String name,  int age){
	this.name = name;
	this.age = age;
    }
    @Override
    public  Student clone(){
	return new Student(name,age);
    }
    @Override
    public String toString(){
	return name+":"+age;
    }
    
    public boolean equals(Object obj){
	//X 物件 是否為 Y類型
	//X instanceof Y 是回傳true 
//	if (obj == null ||  
//		!(obj instanceof Student)){
//	    return false;
//	}

	if (obj == null ||  
		this.getClass().getName() != 
		obj.getClass().getName()){
	    return false;
	}
	Student tmpSt = (Student)obj;
	
	return name.equals(tmpSt.name) 
		&& age == tmpSt.age;
    }
    
  
}
