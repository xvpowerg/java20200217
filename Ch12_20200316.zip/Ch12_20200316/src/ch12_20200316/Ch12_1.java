/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_20200316;
import java.io.IOException;
import java.io.FileNotFoundException;
/**
 *
 * @author xvpow
 */
public class Ch12_1 {

    public static void main(String[] args) {
	//finally 一定會被執行到
//	try{
//	    String name = null;
//	    name.equals("AAA");   
//	}finally{
//	    	System.out.println("Close!!");
//	}
//	try{
//	     int number = 20;
//	      if (number > 10){
//		  return;
//	      }    
//	}finally{
//	    	System.out.println("Close!!");
//	}
	//討論try catch 順序
	
	
	try{
	  throw new FileNotFoundException();  
	}catch(FileNotFoundException ex){
	    System.out.println(ex);
	}
	
	try{
	  throw new FileNotFoundException();  
	}catch(IOException ex){
	    System.out.println(ex);
	}
	
	
	try{
	      String name = null;
	      name.equals("");
	  if (true){
	   throw new FileNotFoundException();       
	  }
//catch 中如果 catch的例外是有繼承關係的時候 上面子下面父
	}catch(FileNotFoundException ex){
	 System.out.println(ex);
	}catch(IOException ex){
	    System.out.println(ex);
	}catch(Exception ex){
	    System.out.println(ex);
	}
	
    }
    
}
