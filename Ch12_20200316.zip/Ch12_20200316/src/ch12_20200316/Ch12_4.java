/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_20200316;

/**
 *
 * @author xvpow
 */
public class Ch12_4 {

 
    public static void main(String[] args) {
	Student st1 = new Student("Ken",12);
	Student st2 = new Student("Ken",12);
	Ch12_4 c124 = new Ch12_4();
	System.out.println(st1.equals(c124));
	
    }
    
}
