/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_20200316;

import java.io.IOException;
import java.io.FileNotFoundException;
import java.sql.SQLException;
public class Test2  extends Test1{
//      public void testException()throws IOException{
//	
//    }
    //OK!!
//    public void testException()throws FileNotFoundException{
//	
//    }
    //不拋出也可以
//     public void testException() {
//	 
//     }
    //錯誤因為SQLException 不是 IOException子類
//       public void testException()throws SQLException { 
//     }
    
    //只要拋的是非必要例外檢測的例外 都可以拋出
    public void testException()throws NullPointerException {
      
    }
}
