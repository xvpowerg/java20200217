/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_20200316;

/**
 *
 * @author xvpow
 */
public class Ch12_5 {
    //靜態 是類別的
    //非靜態的 是物件的
    
    //靜態的只能呼叫靜態的  因為類別產生時沒有物件
    //非靜態的可呼叫 非靜態的與靜態的 因為物件產生時一定有類別
    public static void main(String[] args) {
	Apartment ap1 = new Apartment();
	
	ap1.address = "220新北市板橋區三民路二段69號";
	ap1.count = 6;
	ap1.old = 10;
	//ap1.taiwanCount = 60000000;
	Apartment.taiwanCount = 60000000;//推薦的方式
	Apartment ap2 = new Apartment();
	ap2.address = "100台北市中正區汀州路三段2號";
	ap2.count = 20;
	ap2.old = 5;
	//ap2.taiwanCount = 600000999;
	Apartment.taiwanCount = 600000999;
	System.out.println(ap1);
	System.out.println(ap2);
    }
    
}
