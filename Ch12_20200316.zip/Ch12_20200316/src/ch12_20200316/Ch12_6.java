/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_20200316;

/**
 *
 * @author xvpow
 */
public class Ch12_6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
	Apartment ap1 = Apartment.create();
	ap1.address="XXXX";
	ap1.count = 20;
	ap1.old = 1;
	System.out.println(ap1);
    }
    
}
