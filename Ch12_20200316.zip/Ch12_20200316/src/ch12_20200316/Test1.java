/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_20200316;
import java.io.IOException;
/**
 *
 * @author xvpow
 */
public class Test1 {
    public void testException()
	    throws IOException{
	
    }
}
