/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_20200316;

/**
 *
 * @author xvpow
 */
public class Ch12_2 {

  //clone 深度Copy
    public static void main(String[] args) {
	Student st1 = new Student("Ken",12);
	Student st2 = new Student("Ken",12);

	Student[] s1 = {new Student("Ken",10),
	    new Student("Vivin",20)};
	Student[] copy = new Student[2];
	for (int i= 0;i < copy.length;i++){
	    copy[i] = s1[i].clone(); 
	}
	
	copy[0].name = "Joey";
	for (Student st : copy){
	    
	   
	    System.out.println(st.name +":"+st.age);
	}
	
	for (Student st : s1){
	    System.out.println(st.name +":"+st.age);
	}
    }
    
}
