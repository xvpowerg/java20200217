/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch23_20200413;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

public class Ch23_6 {
    public static void main(String[] args) throws Exception {
	    File src = new File("C:\\MyDir\\msg.txt");
	    File target = new File("C:\\MyDir\\msg_copy.txt");
	    FileInputStream fin = new FileInputStream(src);
	    FileOutputStream fout = new FileOutputStream(target);
	    int data = -1;
	    //-1表示 檔案的結尾
	    while(  (data = fin.read() ) != -1  ){
		fout.write(data);
	    }
    }
    
}
