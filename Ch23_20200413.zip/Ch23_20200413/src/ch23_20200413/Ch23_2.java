/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch23_20200413;

import java.util.ArrayList;
import java.util.stream.Collectors;
import java.util.Map;
/**
 *
 * @author xvpow
 */
public class Ch23_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
	ArrayList<String> arrayList = new  ArrayList<>();
	arrayList.add("Apple");
	arrayList.add("Charry");
	arrayList.add("Kiwi");
	arrayList.add("Banana");
	
	Map<Integer,String> myMap = 
		arrayList.stream().collect(Collectors.toMap(
		(s)->s.length(), (s)->s ,(ov,nv)->ov+":"+nv));
	System.out.println(myMap);
	
    }
    
}
