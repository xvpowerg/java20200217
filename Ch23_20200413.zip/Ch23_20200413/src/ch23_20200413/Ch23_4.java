/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch23_20200413;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 *
 * @author xvpow
 */
public class Ch23_4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
	Student st1 = new Student("Ken",2,18,83);
	Student st2 = new Student("Vivin",1,17,72);
	Student st3 = new Student("Lindy",2,20,95);
	Student st4 = new Student("Lucy",1,17,33);
	Student st5 = new Student("Join",2,18,86);
	Student st6 = new Student("Ben",1,18,73);
	Student st7 = new Student("Tom",1,19,74);
	Student st8 = new Student("Iris",2,20,93);
	
	ArrayList<Student> list = new ArrayList<>();
	list.add(st1);
	list.add(st2);
	list.add(st3);
	list.add(st4);
	list.add(st5);
	list.add(st6);
	list.add(st7);
	list.add(st8);
	//partitioningBy 二分true 或 fase
//	Map<Boolean,List<Student>> map = 
//		list.stream().collect(
//			Collectors.partitioningBy(st->st.getAge() >= 18));
//	System.out.println(map);

//joining() 將字串串接
String name = 
	list.stream().map(st->st.getName()).collect(Collectors.joining(",", "Titile:", "."));
System.out.println(name);
	
    }
    
}
