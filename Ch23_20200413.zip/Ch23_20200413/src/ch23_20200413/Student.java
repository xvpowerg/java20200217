/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch23_20200413;

import java.util.Objects;

/**
 *
 * @author xvpow
 */
public class Student {
    private String name;
    private int classId;
    private int age;
    private int score;

    public Student(String name, int classId, int age, int score) {
	this.name = name;
	this.classId = classId;
	this.age = age;
	this.score = score;
    }

    public String getName() {
	return name;
    }

    public int getClassId() {
	return classId;
    }

    public int getAge() {
	return age;
    }

    public int getScore() {
	return score;
    }

    @Override
    public String toString() {
	return "Student Object{" + "name=" + name + ", classId=" + classId + ", age=" + age + ", score=" + score + '}';
    }

    @Override
    public int hashCode() {
	int hash = 7;
	hash = 29 * hash + Objects.hashCode(this.name);
	hash = 29 * hash + this.classId;
	hash = 29 * hash + this.age;
	hash = 29 * hash + this.score;
	return hash;
    }

    @Override
    public boolean equals(Object obj) {
	if (this == obj) {
	    return true;
	}
	if (obj == null) {
	    return false;
	}
	if (getClass() != obj.getClass()) {
	    return false;
	}
	final Student other = (Student) obj;
	if (this.classId != other.classId) {
	    return false;
	}
	if (this.age != other.age) {
	    return false;
	}
	if (this.score != other.score) {
	    return false;
	}
	if (!Objects.equals(this.name, other.name)) {
	    return false;
	}
	return true;
    }

   
    
    
    
}
