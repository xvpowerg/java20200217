/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch23_20200413;
import java.util.Optional;
import java.util.stream.Stream;
public class Ch23_5 {

    
    public static void main(String[] args) {
	
	Stream<Integer> st1 =  Stream.of(8,2,3,5,7);
//回傳Optional
//parallel 不會影響
//	Optional<Integer> op1 =  st1.reduce((n1,n2)->n1 + n2);
//	System.out.println(op1.get());

// 回傳是一個類型
//	int v2 = st1.reduce(1, (n1,n2)->n1+n2);
//	System.out.println(v2);

//parallel 會影響
//	int v2_2 = st1.parallel().reduce(1, (n1,n2)->n1+n2);
//	System.out.println(v2_2);

  //回傳類型跟	reduce第一個參數有關
//    int v3 = st1.reduce(1, (n1,n2)->n1+n2,(n1,n2)->n1+n2);
//    System.out.println(v3);
//以下如果有了parallel 會全部的數值先加1 (先執行middle的語法)
//在合併 (執行end的語法)
    int v3_2 = st1.parallel().reduce(1, 
	    (n1,n2)->{
		System.out.println("middle:"+n1+":"+n2);
		return  n1+n2;},
	    (n1,n2)->{
		System.out.println("end:"+n1+":"+n2);
		return n1+n2;});
    System.out.println(v3_2);
    }
    
}
