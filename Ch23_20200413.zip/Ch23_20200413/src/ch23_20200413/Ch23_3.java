/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch23_20200413;

/**
 *
 * @author xvpow
 */
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
public class Ch23_3 {

    
    public static void main(String[] args) {
	//public Student(String name, int classId, int age, int score) 
	Student st1 = new Student("Ken",2,18,83);
	Student st2 = new Student("Vivin",1,17,72);
	Student st3 = new Student("Lindy",2,20,95);
	Student st4 = new Student("Lucy",1,17,33);
	Student st5 = new Student("Join",2,18,86);
	Student st6 = new Student("Ben",1,18,73);
	Student st7 = new Student("Tom",1,19,74);
	Student st8 = new Student("Iris",2,20,93);
	
	ArrayList<Student> list = new ArrayList<>();
	list.add(st1);
	list.add(st2);
	list.add(st3);
	list.add(st4);
	list.add(st5);
	list.add(st6);
	list.add(st7);
	list.add(st8);
	//使用班級做群組
//	Map<Integer,List<Student>>  group =
//		list.stream().
//		collect(Collectors.groupingBy(st->st.getClassId()));
//	System.out.println(group);
//使用班級 與 年齡群組
 Map<Integer,Map<Integer,List<Student>>>  group2 =
		list.stream().
		collect(Collectors.groupingBy((st)->st.getClassId(), 
			Collectors.groupingBy(st->st.getAge())));
	System.out.println(group2);
//使用班級 與 年齡群組 後將他們的成績加總
Map<Integer,Map<Integer,Integer>> group3 =
		list.stream().
		collect(Collectors.groupingBy((st)->st.getClassId(), 
			Collectors.groupingBy(st->st.getAge(),
			 Collectors.mapping(st->st.getScore(), 
				 Collectors.summingInt(s->s)))));
	System.out.println(group3);

//   int sum = list.stream().collect(Collectors.mapping(st->st.getScore(), 
//				Collectors.summingInt(s->s)));
//	System.out.println(sum);
    }
    
}
