/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch22_20200410;
import java.util.stream.Stream;
import java.util.ArrayList;
public class Ch22_1 {
     static void println(String str){
	 System.out.println(str);
     }
    public static void main(String[] args) {
	//Stream 特性
	//Stream 不會改變來源
	//Stream 有分為惰性layz與終端Terminal
	//同一Stream只能使用一次
	ArrayList<String> list = new ArrayList<>();
	list.add("Ken");
	list.add("Vivin");
	list.add("Join");
	list.add("Lindy");
	//Stream 不會改變來源
	Stream<String> st = list.stream();
	st.filter(n->n.length() > 3).forEach(System.out::println);
	System.out.println(list.size());
	//Stream 有分為惰性layz (不會有動作)與終端Terminal(會有動作)
	Stream<String> s2 =   list.stream();
	long count =  s2.peek(n->System.out.println("Peek 1:"+n)).
		filter(n->n.length() > 3).
		peek(n->System.out.println("Peek 2:"+n)).count();
	System.out.println(count);
	//同一Stream只能使用一次
	Stream<String> s3 =   list.stream();
	 Stream<String> s4 =  s3.limit(3);
	 Stream<String> s5 =   s4.skip(2);//同一Stream只能使用一次
	 //Stream<String> s5 =   list.stream().skip(2);
	 System.out.println("==================");
	 s5.forEach(System.out::println);
    }
    
}
