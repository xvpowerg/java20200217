/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch22_20200410;

import java.util.ArrayList;

/**
 *
 * @author xvpow
 */
public class Ch22_2 {
    public static void main(String[] args) {
	ArrayList<String> list = new ArrayList<>();
	list.add("Vivin");
	list.add("Join");
	list.add("Ken");
	list.add("Lindy");

	boolean b1 = list.stream().allMatch(n->n.length() > 2);//所有條件符合回傳true
	System.out.println(b1);
	boolean b2 = list.stream().allMatch(n->n.length() > 3);
	System.out.println(b2);
	
	boolean b3 = list.stream().anyMatch(n->n.indexOf("e") > -1);//任一條件符合回傳true
	System.out.println(b3);
	boolean b4 = list.stream().anyMatch(n->n.indexOf("z") > -1);
	System.out.println(b4);  
	
       boolean b5 = list.stream().noneMatch(n->n.startsWith("Y"));//沒有任何一條件符合回傳true
	System.out.println(b5); 
	boolean b6 = list.stream().noneMatch(n->n.startsWith("K"));
	System.out.println(b6); 
    }
    
}
