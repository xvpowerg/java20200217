/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch22_20200410;

import java.util.ArrayList;

/**
 *
 * @author xvpow
 */
public class Ch22_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
	ArrayList<String> list = new ArrayList<>();
	list.add("Vivin");
	list.add("Join");
	list.add("Ken");
	list.add("Lindy");
	//allMatch 只要有條件不成立就短路 並且回傳false
	boolean b1 = list.stream().peek(System.out::println).
			allMatch(n->n.length() > 3);//所有條件符合回傳true
	System.out.println(b1);
	System.out.println("======================");
	//anyMatch 只要有條件成立就短路 回傳true
	boolean b2 = list.stream().peek(System.out::println).anyMatch(n->n.indexOf("e") > -1);//任一條件符合回傳true
	System.out.println(b2);
	System.out.println("======================");
	//anyMatch 只要有條件成立就短路 並且回傳false
	boolean b5 = list.stream().peek(System.out::println).noneMatch(n->n.startsWith("J"));//沒有任何一條件符合回傳true
	System.out.println(b5); 
	
    }
    
}
