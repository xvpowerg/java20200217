/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch22_20200410;
import java.util.Optional;
public class Student {
    private String name;

    public Student(String name) {
	this.name = name;
    }

    public Optional<String> getName() {
	return Optional.ofNullable(name);
    }
    
}
