/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch22_20200410;

import java.util.ArrayList;
import java.util.Optional;
public class Ch22_5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
   ArrayList<String> list = new ArrayList<>();
    list.add("Apple");
    list.add("Banana");
    list.add("Charray");
    
    Optional<String> opt =list.stream().findFirst();//找到第一個
	if (opt.isPresent()){
	    System.out.println(opt.get());
	}
    Optional<String> opt2 =list.parallelStream().findAny();//如果是parallelStream 才會啟動任一組的效果 不然會跟findFirst一樣
    if (opt2.isPresent()){
	    System.out.println(opt2.get());
	}
    }
}
