/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch22_20200410;
import java.util.stream.Stream;
import java.util.ArrayList;
public class Ch22_4 {
    static class Fruit{
	private String name;
	public Fruit(String name){
	    this.name = name;
	}
	public String toString(){
	    return name;
	}
    }
    public static void main(String[] args) {
	//map 作用 把A類型的Stream 轉換成B類型的Stream
    
    ArrayList<String> list = new ArrayList<>();
    list.add("Apple");
    list.add("Banana");
    list.add("Charray");
    ArrayList<String> list2 = new ArrayList<>();
    list.add("Peach");
    list.add("Pineapple");
    list.add("Orange");
    
    list.stream().map(fn->new Fruit(fn)).forEach(System.out::println);//map 方法內回傳任一物件
     //list.stream().flatMap(mapper)//flatMap 方法內回傳Stream
   Stream<ArrayList<String>> listStr = Stream.of(list,list2);
    Stream<String> st3 = listStr.flatMap(list3->list3.stream());//把flatMap內的Stream攤平
    st3.forEach(System.out::println);
    //list.stream().map(Fruit::new).forEach(System.out::println);
    //mapToInt 記得內部的方法回傳int 最結果會回傳 IntStream
   int sum =  list.stream().mapToInt(s->s.length()).sum();
   System.out.println(sum);
    
    }
    
}
