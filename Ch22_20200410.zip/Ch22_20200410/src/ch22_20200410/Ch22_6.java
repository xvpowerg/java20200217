/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch22_20200410;

import java.util.Optional;

public class Ch22_6 {
    public static void main(String[] args) {
//	Student st1 = new Student(null);    
//	if (st1.getName().isPresent() && st1.getName().get().length() > 10){
//	    System.out.println("Name 大於10");
//	}
        //Optional.of(null);//java.lang.NullPointerException
      String msg = "Test";
      Optional.ofNullable(msg).ifPresent(System.out::println);
      String  v1 = Optional.ofNullable(msg).orElse("Default");//如果不存在回傳Default
      System.out.println(v1);
      String  v2 = 
	      Optional.ofNullable(msg).orElseGet(()->"ElseGet!!");
       System.out.println(v2);
        String  v3 = 
	Optional.ofNullable(msg).orElseThrow(()->new IllegalArgumentException());
     System.out.println(v3); 
    }
    
}
