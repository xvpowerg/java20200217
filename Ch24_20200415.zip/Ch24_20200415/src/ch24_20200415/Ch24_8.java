/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch24_20200415;
import java.io.File;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
public class Ch24_8 {
    public static void main(String[] args) throws Exception {
	    File file = new File("c:\\MyDir\\product.obj");
	    try (FileInputStream fin = new FileInputStream(file);
	      ObjectInputStream objin = new ObjectInputStream(fin);){
		    Product prod = (Product)objin.readObject();
		   System.out.println(prod);
	    }
    }
    
}
