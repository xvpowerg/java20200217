/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch24_20200415;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
public class Ch24_1 {
    public static void main(String[] args) {
	    File src = new File("C:\\MyDir\\msg.txt");
	    File target = new File("C:\\MyDir\\msg_copy.txt");
	    int data = -1;
	    try{
		 FileInputStream fin = new FileInputStream(src);
		 FileOutputStream fOut = new FileOutputStream(target);
		    while( (data = fin.read()) != -1  ){
				fOut.write(data);
		     }
	    }catch(FileNotFoundException ex){
		System.out.println(ex);
	    }catch(IOException ex){
		System.out.println(ex);
	    } 
    }
}
