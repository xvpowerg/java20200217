/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch24_20200415;
import java.io.File;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
/**
 *
 * @author xvpow
 */
public class Ch24_5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
	//序列化 分2階
	//1 物件變檔案
	File f1 = new File("C:\\mydir\\mySerializ.data");
	String value1 = "Howard";
	try(FileOutputStream fout = new FileOutputStream(f1);
	   ObjectOutputStream objOut = new ObjectOutputStream(fout)){
	    objOut.writeObject(value1);
	}catch(FileNotFoundException ex){
	    System.out.println(ex);
	}catch(IOException ex){
	    System.out.println(ex); 
	}
	
	
	
    }
    
}
