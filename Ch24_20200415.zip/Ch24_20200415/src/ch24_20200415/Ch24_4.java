/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch24_20200415;

public class Ch24_4 {
    static class TestClose1 implements AutoCloseable{
	    public void close(){
		System.out.println("TestClose1");
		
	    }
    }
    static class TestClose2 implements AutoCloseable{
	public void close(){
	    System.out.println("TestClose2");
	    throw new IllegalStateException("TestClose2 Exception");
	}
    } 
    /*
    TestClose2 先關
    TestClose1 在關
    */
    public static void main(String[] args) {
//	try(TestClose1 t1 = new TestClose1();
//	    TestClose2 t2 = new TestClose2()){
//	}

//在Body有例外
//	try(TestClose1 t1 = new TestClose1();
//	    TestClose2 t2 = new TestClose2()){
//	    System.out.println("Body...");
//	    throw new IllegalArgumentException("Test Body  Exception");
//	}catch(Exception ex){
//	    System.out.println(ex);
//	}
//在Body有例外 TestClose2 有例外
//    try(TestClose1 t1 = new TestClose1();
//		TestClose2 t2 = new TestClose2()){
//		System.out.println("Body...");
//		throw new IllegalArgumentException("Test Body  Exception");
//	    }catch(Exception ex){
//		//TestClose2 Exception 被 抑制了(Suppressed)
//		Throwable[] th = ex.getSuppressed();
//		System.out.println(th[0]);
//		//表面的例外 看最早拋出例外的Exceptin類別為表面例外
//		System.out.println(ex);
//	    }
//在Body有例外 TestClose2 有例外 加上finally
   try(TestClose1 t1 = new TestClose1();
		TestClose2 t2 = new TestClose2()){
      // t2 = new TestClose2();//不能再重新給予數值
      
		System.out.println("Body...");
		throw new IllegalArgumentException("Test Body  Exception");
	    }catch(Exception ex){
		//TestClose2 Exception 被 抑制了(Suppressed)
		Throwable[] th = ex.getSuppressed();
		System.out.println(th[0]);
		//表面的例外 看最早拋出例外的Exceptin類別為表面例外
		System.out.println(ex);
	    }finally{
		System.out.println("TestClose finally");    
	     }

	
    }
}
