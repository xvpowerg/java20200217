/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch24_20200415;

import java.io.File;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;

public class Ch24_7 {
    public static void main(String[] args) throws Exception {
	File file = new File("c:\\MyDir\\product.obj");
	Product p1 = new Product(1,"Address!!!","Apple",10);
	  try(FileOutputStream fout = new FileOutputStream(file);
	     ObjectOutputStream  objOut = new ObjectOutputStream(fout)){
	     objOut.writeObject(p1);
	  }  
    }
    
}
