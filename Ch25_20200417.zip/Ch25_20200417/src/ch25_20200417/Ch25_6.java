/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch25_20200417;

/**
 *
 * @author xvpow
 */
public class Ch25_6 {

    static class Test1{
	static int count = 0;
	//synchronized 加在方法上時
	//此方法正被Thread1控制且未完成時,其他執行序無法摻與
      synchronized void  add(){
	    for (int i =1;i<=30;i++){
		count++;
		System.out.println(count);
	    }
	}
    }
    public static void main(String[] args) {
	Test1 test1 = new Test1();
	Runnable run = ()->{
	     test1.add();
	};
	Thread th1 = new Thread(run);
	Thread th2 = new Thread(run);
	th1.start();
	th2.start();
    }
    
}
