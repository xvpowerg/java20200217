/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch25_20200417;
import java.nio.file.Paths;
import java.nio.file.Path;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.io.IOException;
public class Ch25_2 {

    public static void main(String[] args) {
	
	Path src = Paths.get("C:", "MyDir","msg.txt");
	Path target = Paths.get("C:", "MyDir","msg_copy.txt");
	
	Path moveSrc = Paths.get("C:", "MyDir","test.zip");
	Path moveTarget = Paths.get("C:", "MyDir","Dir2","test_move.zip");
	try{
	    //預設情況下copy與move的目標檔案名稱不可重複的
	    //copy不可用 ATOMIC_MOVE
//	    Files.copy(src, target,StandardCopyOption.REPLACE_EXISTING,
//		    StandardCopyOption.COPY_ATTRIBUTES);
	    //Move 等於Copy and Delete
	    
	    //move 不可用StandardCopyOption.COPY_ATTRIBUTES
	    Files.move(moveSrc, moveTarget,StandardCopyOption.COPY_ATTRIBUTES);
	}catch(IOException ex){
	    System.out.println(ex);
	}
	
	
	
	
    }
    
}
