/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch25_20200417;
import java.nio.file.Paths;
import java.nio.file.Path;
import java.nio.file.Files;
import java.io.IOException;
import java.util.stream.Stream;
public class Ch25_3 {

    public static void main(String[] args) {
	Path path = Paths.get("C:","MyDir");
//	try{
//	 //只會顯示指定目錄的表層
//	    Stream<Path>  stPah =  Files.list(path); 
//	   //只有zip檔才出現
//	   stPah.filter(p->p.toString().endsWith(".zip")).
//		   forEach(System.out::println);
//	   //stPah.forEach(System.out::println);
//	}catch(IOException ex){
//	    System.out.println(ex);
//	}
	 try {
	     //預設walk的maxDepth深度為Integer最大值
	    //maxDepth 為0 則目前case而言顯示 C:\MyDir
	  Stream<Path> st =  Files.walk(path,3);
	  st.forEach(System.out::println);
	} catch (IOException ex) {
	    System.out.println(ex);
	}
	
	
    }
    
}
