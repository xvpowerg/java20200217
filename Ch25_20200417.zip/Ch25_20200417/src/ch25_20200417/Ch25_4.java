/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch25_20200417;
import java.nio.file.Paths;
import java.nio.file.Path;
import java.nio.file.Files;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.List;
import java.util.stream.Stream;
public class Ch25_4 {

    public static void main(String[] args)throws Exception {
	Path src = Paths.get("C:", "MyDir","msg.txt");
	//可使用 Charset.forName("BIG5") 修改編碼
//	List<String> list =  Files.readAllLines(src);
//	list.forEach(System.out::println);
	
	Stream<String> st = 	Files.lines(src);
	//st.forEach(System.out::println);
	//計算文章字數
	long count = st.flatMap(v->Stream.of(v.split(""))).count();
	System.out.println(count);
    }
    
}
