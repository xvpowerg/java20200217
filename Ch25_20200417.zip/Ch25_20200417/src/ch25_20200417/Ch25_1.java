/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch25_20200417;
import java.nio.file.Paths;
import java.nio.file.Path;
import java.nio.file.Files;
public class Ch25_1 {

    public static void main(String[] args) {
	// Paths.get 是呼叫 FileSystems.getDefault().getPath 
	Path ph1 =  Paths.get("C:", "test1","myDir","msg.txt");
	System.out.println(ph1);
	System.out.println("getFileName:"+ph1.getFileName());//msg.txt
	System.out.println("getFileName:"+ph1.getName(1));//myDir
	System.out.println("getNameCount:"+ph1.getNameCount());//3
	System.out.println("Root:"+ph1.getRoot());
	System.out.println("isAbsolute:"+ph1.isAbsolute());
	//normalize  ./ 會被移除
	//normalize ../ 如果 ../ 前面有目錄會被移除
	Path ph2 = Paths.get(".././../MyDir/Dir2");
        Path ph2_2 = Paths.get("MyDoc/MyDoc2/../../MyDir/Dir2");
	System.out.println("normalize:"+ph2.normalize());
	System.out.println("normalize:"+ph2_2.normalize());
	Path ph3 = Paths.get("C:", "teat1","test2","test2_1");
	Path ph4 = Paths.get("C:", "teat1","test2","test2_2");
	//relativize 不可跨Root
	Path newPh5  = ph3.relativize(ph4);
	System.out.println(newPh5);
	//如果右邊的目錄是絕對路徑 新的目錄 會變為右邊的目錄
	//resolve  合併目錄
	Path ph6 = Paths.get("C:", "test1","test2");
	Path ph7 = Paths.get("test2_1");
	Path ph8 = ph6.resolve(ph7);
	System.out.println(ph8);
	
	Path ph9 = Paths.get("C:", "test1","test2");
	Path ph10 = Paths.get("D:","test2_1");
	System.out.println(ph9.resolve(ph10));
	
    }
    
}
