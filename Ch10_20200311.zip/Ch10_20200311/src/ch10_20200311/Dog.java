/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20200311;

//繼承不會繼承來自於父類別的
//1 建構子
//2 私有的?
//3 default修改權限下 不同package 不會繼承 
//繼承 只能單一繼承
//所有的類別都預設繼承了Object

public class Dog extends Animal {
    //java 內所有建構子預設都會呼叫父類別的預設構子
    //除了 在建構子內 有自行呼叫this() 或 super()
   Dog(){
   }
   
   Dog(String name,int age,float height){
       //呼叫父類別的建構子
       //super() 只能是建構子的第一個命令
       super(name,age,height);
//      this.setName(name);
//      this.setAge(age);
//      this.setHeight(height);
   }
   //覆寫 只有在有繼承關係時 去覆蓋父類別的方法 就叫做覆寫
   //Override
   public String getName(){
       //super. 可呼叫父類別的非私有的屬性 或方法
      return "Dog:" + super.getName();
   }
   
}
