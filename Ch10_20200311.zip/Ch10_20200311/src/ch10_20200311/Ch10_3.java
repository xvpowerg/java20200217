/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20200311;

/**
 *
 * @author xvpow
 */
public class Ch10_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
	Animal dog1 = new Dog("Snopy",51,25);
	System.out.println(dog1.getName()+":"+dog1.getAge());
	Animal cat1 = new Cat("Mimi",2,10);
	System.out.println(cat1.getName()+":"+cat1.getAge());
	
	Object dog = new Dog();
	
	
    }
    
}
