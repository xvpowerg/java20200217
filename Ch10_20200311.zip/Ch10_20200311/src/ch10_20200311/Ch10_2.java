/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20200311;

/**
 *
 * @author xvpow
 */
public class Ch10_2 {

    /**
     * @param args the command line arguments
     */
    //最佳標準:低耦合
    static void printAnimal(Animal animal){
	System.out.println(animal.getName()+":"+animal.getAge());
    }
    public static void main(String[] args) {
	//多形 Polymorphism
	//多行好處 
	//最佳標準:低耦合 高聚合
	Animal dog1 = new Dog("Dofi",1,5.6f);
	System.out.println(dog1.getName());
	System.out.println(dog1.getAge());
	System.out.println(dog1.getHeight());
	
	printAnimal(new Dog());
	printAnimal(new Cat());
    }
    
}
