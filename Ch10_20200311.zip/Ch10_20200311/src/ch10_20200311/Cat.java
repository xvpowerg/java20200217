/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20200311;

/**
 *
 * @author xvpow
 */
public class Cat extends Animal{
    Cat(){	
    }
   Cat(String name,int age,float height){
       super(name,age,height);
   } 
   @Override //檢查是否是正確的Override
   public String getName(){
       return "Cat:"+ super.getName();
   }
}
