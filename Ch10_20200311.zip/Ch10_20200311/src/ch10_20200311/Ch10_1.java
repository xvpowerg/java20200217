/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20200311;

/**
 *
 * @author xvpow
 */
public class Ch10_1 {

    public static void main(String[] args) {
	Dog dog1 = new Dog();
	dog1.setName("BeBo");
	System.out.println(dog1.getName());
	Dog dog2 = new Dog("Money",2,20);
	System.out.println(dog2.getName());
	Dog dog3 = new Dog();
	System.out.println(dog3.getName()+":"
		+dog3.getAge()+":"+dog3.getHeight());
	Cat cat1 = new Cat();
	System.out.println(cat1.getName());
//	cat1.setName("Kitty");
//	System.out.println(cat1.getName());
    }
    
}
