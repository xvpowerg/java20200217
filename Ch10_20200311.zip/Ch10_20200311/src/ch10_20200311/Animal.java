/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20200311;

//多個物件相同的方法寫在一個類別內
public class Animal {
     private String name;
    private int age;
    private float height;
	//預設建構子 沒特別需求就建起來
    	Animal(){
	   //呼叫目前類別另一組建構子
        //this() 只能是建構子的第一個命令
	this("未設定",-1,-1);
	}
	Animal(String name,int age,float height){
	    this.name = name;
	    this.age = age;
	    this.height = height;
	}
    
    
    //如果是區域變數 會找最接近的變數名稱
    public void setName(String name){
	//this 表示目前這個物件
	this.name = name;
    }
    public String getName(){
	return name;
    }
    public void setAge(int age){
	this.age = age;
    }
    
    public int getAge(){
	return age;
    }
 
    public void setHeight(float height){
	this.height = height;
    }
    public float getHeight(){
	return height;
    }
}
