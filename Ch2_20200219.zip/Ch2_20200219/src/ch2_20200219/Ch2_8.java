/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch2_20200219;


public class Ch2_8 {
    public static void main(String[] args){
	//且 AND && & 兩邊為真才為真
	//或 OR || | 單邊為真就是真
	//反向 NOT ! 唱反調
	//互斥 XOR ^ 一真一假才為真
	
	//&  |  ^ 可做數字運算
	//&  |  ^ 邏輯運算不會有短路現象
	//&& || 會出現短路現象
	
	boolean b1 = true;
	boolean b2 = false;
	System.out.println(b1 && b2);
	System.out.println(b1 || b2);
	System.out.println(!b2);
	//小心會考
	//短路現象
	//且 && 左邊為fasle 不往右邊執行
	//意思把可排除的條件放在左邊
	int x = 0;
	boolean b3 = b1 && ++x < 3;
	System.out.println("b3:"+b3);
	System.out.println("x:"+x);
	//&&的短路現象發生了!
	 b3 = b2 && ++x < 3;
        System.out.println("b3:"+b3);
	System.out.println("x:"+x);
	//或 ||的短路現象 左邊為true 不往右邊執行
	//因為b2是false 所以 會執行右邊++x
	b3 = b2 || ++x < 3;
	System.out.println("b3:"+b3);
	System.out.println("x:"+x);
	//因為b1是true就不往右邊
	b3 = b1 || ++x < 3;
	System.out.println("b3:"+b3);
	System.out.println("x:"+x);
	
    }
}
