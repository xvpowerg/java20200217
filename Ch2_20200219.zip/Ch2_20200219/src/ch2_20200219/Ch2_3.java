/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch2_20200219;

/**
 *
 * @author xvpow
 */
public class Ch2_3 {
    public static void main(String[] args){
	int k = 2;
	int g = 7;

	int ans = k++ + k + --g + ++k;
	//1       2   + k + --g + ++k   k=3 g=7
	//2       2   + 3 + --g + ++k   k=3 g=7
	//3       2   + 3 + 6  + ++k    k=3 g = 6
	//4       2   + 3 + 6  + 4      k=4 g=6   
	System.out.println(ans);
        System.out.println(k);
	System.out.println(g);

    }
}
