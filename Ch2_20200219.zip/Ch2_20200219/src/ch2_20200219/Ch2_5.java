/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch2_20200219;

/**
 *
 * @author xvpow
 */
public class Ch2_5 {
    public static void main(String[] args){
        // 字串加法說明
	//字串加任何東西都會變字串
	//會考
	String title = "Number:";
	int value = 35;
	System.out.println(title+value);
	int n1 = 20;
	int n2 = 70;
	System.out.println(title+n1+n2);
	System.out.println(title+(n1+n2));
	
	
	
	
    }
}
