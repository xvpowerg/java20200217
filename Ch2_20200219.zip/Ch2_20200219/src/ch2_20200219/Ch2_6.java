/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch2_20200219;

/**
 *
 * @author xvpow
 */
public class Ch2_6 {
    //比較運算子
    public static void main(String[] args){
	//基本型態比大小
	int n1 = 20;
	int n2 = 30;
	System.out.println(n1 > n2);
	System.out.println(n1 < n2);
	System.out.println(n1 >= n2);
	System.out.println(n1 <= n2);
	//n1是否等於n2
	System.out.println(n1 == n2);
	//n1不等於n2
	System.out.println(n1 != n2);
	//輸出30
	System.out.println(n1 = n2);
    }
}
