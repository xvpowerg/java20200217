/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch2_20200219;

/**
 *
 * @author xvpow
 */
public class Ch2_1 {
    public static void main(String[] args) {
	//會考!!!!!
	    //累加或累減 一元運算
	    //++count的分解動作
//	    int count = 0;
//	    count = count + 1;
//	    System.out.println(count);
//	    count = count + 1;
//	   System.out.println(count);
	//簡化以上程式
//	int count2 = 0;
//	System.out.println(++count2);
//	System.out.println(++count2);
//    int count3 = 0;
//    System.out.println(count3);
//    count3 = count3 + 1;
//    System.out.println(count3);
//    count3 = count3 + 1;
//   System.out.println(count3);
   int count4 = 0;  
    System.out.println(count4++);
    System.out.println(count4);
    System.out.println(count4++);
    System.out.println(count4);
    
    }
    
}
