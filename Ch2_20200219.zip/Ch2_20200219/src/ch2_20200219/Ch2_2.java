/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch2_20200219;

/**
 *
 * @author xvpow
 */
public class Ch2_2 {
    public static void main(String[] args){
//	int k = 5;
//	int y = 2;
//	int v = y +2+ ++k;
//	    v = y + 2 + 6;
//	    v = 2 + 2 + 6;
//	System.out.println(v);
//	
//	int k2 = 5;
//	int y2 = 2;
//	int v2 = y2 +2+ k2++;	      
//	System.out.println(v2);
	
     int i = 2, u = 5;
     int x = ++i + i++ + u-- + i++;
	  //1 3 + i++ + u-- + i++
	  //2 3 +  3  + u-- + i++
	  //3 3 +  3  + 5 + i++
	  //4 3 + 3 + 5 +  4
  //i = 5	  
  //u = 4
  //x = 15
  //3 + 3 + 5 + 4             		
     System.out.println(x);
     System.out.println(i);	
     System.out.println(u);	

	
	
    }
}
