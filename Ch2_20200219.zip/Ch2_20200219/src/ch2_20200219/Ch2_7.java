/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch2_20200219;

/**
 *
 * @author xvpow
 */
public class Ch2_7 {
    //物件(參考型別)之間的比較是否相等
    public static void main(String[] args){
	//字串池
	 String s1 = "Ken";
	 String s2 = "Ken";
	 String s3 = new String("Ken");
	 
	 System.out.println(s1);
	 System.out.println(s2);
	 System.out.println(s3);
	
	System.out.println(s1 == s2);//true
	System.out.println(s1 == s3);//false
	//物件(參考型別)的比較
	System.out.println(s1.equals(s2));//true
	System.out.println(s1.equals(s3));//true
	
    }
}
