/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch2_20200219;

/**
 *
 * @author xvpow
 */
public class Ch2_4 {
    public static void main(String[] args){
	    int number = 2;
	    number = number * 2;
	    number = number * 2;
	    number = number * 2;
	    System.out.println(number);
	   //複合指定運算子
	      number *= 2;
	    System.out.println(number);   
	    int pizz = 18;
	    pizz = pizz / 2;
	    pizz = pizz / 2;
	    System.out.println(pizz);
	    //複合指定運算子  
	    pizz /= 2;  
	   System.out.println(pizz);
	 //*
	//注意 因為等號左邊為int 所以會無條件設捨去
	   int n1 = 10;
	   float f2= 2.5f;
	   n1 += f2;
	   System.out.println(n1);
	
    }
}
