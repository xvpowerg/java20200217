/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch20_20200406;
import java.util.TreeSet;
public class Ch20_2 {

    public static void main(String[] args) {
	TreeSet<Fruit> set = new TreeSet<>();
	Fruit f1 = new Fruit("Apple","Red",30);
	Fruit f2 = new Fruit("Banana","Yellow",25);
	Fruit f3 = new Fruit("KiWi","Green",15);
	Fruit f4 = new Fruit("Charry","Red",25);
	Fruit f5 = new Fruit("KiWi","Golden",15);
	set.add(f1);
	set.add(f2);
	set.add(f3);
	set.add(f4);
	set.add(f5);
	set.forEach(System.out::println);
	
    }
    
}
