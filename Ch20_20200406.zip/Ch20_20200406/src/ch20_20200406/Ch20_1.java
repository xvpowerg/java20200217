/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch20_20200406;

import java.util.LinkedList;
import java.util.Queue;

/**
 *
 * @author xvpow
 */
public class Ch20_1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
	Queue<String> queue = new LinkedList<>();
	queue.add("Ken");
	queue.add("Vivin");
	queue.add("Join");
	
	while(!queue.isEmpty() ){
	   String name = queue.poll();
	   System.out.println(name);
	}
	
    }
    
}
