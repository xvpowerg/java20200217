/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch20_20200406;

import java.util.HashMap;

/**
 *
 * @author xvpow
 */
public class Ch20_6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
	HashMap<Integer,String> map = new HashMap<>();
	map.put(10, "Ken");
	map.put(12, "Vivin");
	map.put(6, "Join");
	map.put(7, "Yumi");
	
	
	
	//不管Key 是否存在都會執行後面的function
	//如果key 存在覆蓋  不存在寫入新的
	map.compute(10,(key,ov)->{
		System.out.println(key+":"+ov);		
	    return "Tom";});
	System.out.println(map.get(10));
	map.compute(5,(key,ov)->{
		System.out.println(key+":"+ov);		
	    return "Ben";});
	System.out.println(map.get(5));
	//key不存在才執行後會的function
	map.computeIfAbsent(52,(key)->{
	    System.out.println("Key:"+key);
	    return "Lindy";
	});
	System.out.println(map.get(52));
    }
    
    //
    
    
}
