/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch20_20200406;
import java.util.HashMap;
/**
 *
 * @author xvpow
 */
public class Ch20_5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
	HashMap<Integer,String> map = new HashMap<>();
	map.put(10, "Ken");
	map.put(12, "Vivin");
	map.put(6, "Join");
	map.put(7, "Yumi");
	map.put(6, "Iris");//如果key重複會取代舊值
	if (map.containsKey(8)){
	    System.out.println("Key存在!");
	}else{
	    System.out.println("Key不存在!");
	}
	System.out.println(map.get(6));
	
	map.putIfAbsent(10, "Ben");//如果key不存在才寫入
	System.out.println(map.get(10));
	
	
	
    }
    
}
