/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch20_20200406;
import java.util.Map;
import java.util.HashMap;
import java.util.Set;
public class Ch20_4 {

    public static void main(String[] args) {
	//key 不可重複 value:可以重複
	Map<Integer,String> myMap = new HashMap();
	myMap.put(10, "Ken");
	myMap.put(12, "Vivin");
	myMap.put(6, "Join");
	myMap.put(7, "Yumi");
	
	System.out.println(myMap.get(6));
	System.out.println(myMap.get(100));//找不到Key回傳null
	//輪巡 2方案
	 Set<Integer> keySet = myMap.keySet();
	keySet.forEach(k->{
	     System.out.println(myMap.get(k));
	});
	System.out.println("=================");
	myMap.entrySet().forEach(entry->{
	    System.out.println(entry.getKey()+":"+entry.getValue());
	});
	
    }
    
}
