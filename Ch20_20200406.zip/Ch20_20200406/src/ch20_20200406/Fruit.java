/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch20_20200406;

/**
 *
 * @author xvpow
 */
public class Fruit implements Comparable<Fruit> {
    private String name;
    private int price;
    private String color;
    //由大到小 遞減排序DESC
  public int compareTo(Fruit f){
      int reault = 0;
	if (this.getPrice() > f.getPrice()){
	    reault= 1;
	}else if(this.getPrice() < f.getPrice()){
	    reault= -1;
	}else{
	   int cmpAns =  this.getName().compareTo(f.getName());
	  reault= cmpAns ==0?this.getColor().compareTo(f.getColor()):cmpAns;  
	}
	return reault * -1;
    }
//    public int compareTo(Fruit f){
//	if (this.getPrice() > f.getPrice()){
//	    return 1;
//	}else if(this.getPrice() < f.getPrice()){
//	    return -1;
//	}else{
//	   int cmpAns =  this.getName().compareTo(f.getName());
//	  return cmpAns ==0?this.getColor().compareTo(f.getColor()):cmpAns;  
//	}
//    }
    public Fruit(String name, String color,int price) {
	this.name = name;
	this.price = price;
	this.color = color;
    }

    public String getName() {
	return name;
    }

    public int getPrice() {
	return price;
    }

    public String getColor() {
	return color;
    }

    
    
    public String toString(){
	return this.getName()+":"+this.getColor()+":"+this.getPrice();
    }
}
