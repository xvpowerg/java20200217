/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch20_20200406;

/**
 *
 * @author xvpow
 */
public class Employee {
    private String name;
    private int salary;    
    private int year;

    public Employee(String name, int salary, int year) {
	this.name = name;
	this.salary = salary;
	this.year = year;
    }

    public String getName() {
	return name;
    }

    public int getSalary() {
	return salary;
    }

    public int getYear() {
	return year;
    }

    @Override
    public String toString() {
	return "Employee{" + "name=" + name + ", salary=" + salary + ", year=" + year + '}';
    }
}
