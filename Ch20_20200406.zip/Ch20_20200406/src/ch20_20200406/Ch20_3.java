/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch20_20200406;
import java.util.TreeSet;
import java.util.Comparator;
/**
 *
 * @author xvpow
 */
public class Ch20_3 {
     
    
     private static class EmpComparator implements Comparator<Employee>{
	  public int compare(Employee e1,Employee e2){
	      if (e1.getYear()  < e2.getYear()){
		  return -1;
	      }else if(e1.getYear() > e2.getYear()){
		  return 1;
	      }
	      int result = e1.getName().compareTo(e2.getName());
	     result = result==0?e1.getSalary() - e2.getSalary():result;
	      return result;
	  }  
     }
    public static void main(String[] args) {
	EmpComparator empComp = new EmpComparator();
	Employee emp1 = new Employee("Ken",35000,3);
	Employee emp2 = new Employee("Vivin",25000,1);
	Employee emp3 = new Employee("Joy",56000,2);
	Employee emp4 = new Employee("Iris",78000,7);
	Employee emp5 = new Employee("Ben",35000,2);
	Employee emp6 = new Employee("Iris",82000,7);
	//TreeSet<Employee> empSet = new TreeSet<>(empComp);
	//java8開始可用的排序
	Comparator<Employee> myComp = 
		Comparator.<Employee,Integer>comparing(e->e.getYear()).
			thenComparing(e->e.getName()).
			thenComparing(e->e.getSalary());
	//myComp = myComp.reversed();//由大到小
	TreeSet<Employee> empSet = new TreeSet<>(myComp);
	empSet.add(emp1);
	empSet.add(emp2);
	empSet.add(emp3);
	empSet.add(emp4);
	empSet.add(emp5);
	empSet.add(emp6);
	empSet.forEach(System.out::println);
    }
    
}
