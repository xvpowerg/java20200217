/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch8_20200306;

import java.util.stream.IntStream;
import java.util.stream.Stream;

/**
 *
 * @author xvpow
 */
public class Ch8_1 {
//作業
    //1 寫一個方法 可傳入n筆數字 或不傳入數字
     // 幫我回傳一個陣列 陣列內容為 傳入參數偶數的數字
    static int[] filterEven(int ... values){
	int count = 0;
	//計算偶數有幾筆
	for (int v :values ){
	    if (v % 2 == 0)count++;
	}
	//給與偶數陣列的長度
	 int[] evenArray = new int[count];
	    count = 0;
	//偶數資料寫入陣列
	for (int v : values){
	      if (v % 2 == 0) evenArray[count++] = v;
	}
	return evenArray;
    }
    //2,6,7,1,5,8,9
    static int[] filterEven2(int ... values){
	//values.length + 1 多一筆 因為要存放偶數數量
	int[] tmpArray = new int[values.length + 1];
	int lastIndex = tmpArray.length - 1;
	for (int v : values){
	    if (v %2 == 0){
		//是偶數放置於tmpArray
		//tmpArray的最後一筆表示為 偶數數量
		tmpArray[tmpArray[lastIndex]++] = v;
	    }
	}
	return tmpArray;
    }
   
    public static void main(String[] args) {
	// TODO code application logic here
	int [] evenArray = filterEven(2,6,7,1,5,8,9);
	for (int v : evenArray){
	    System.out.print(v+" ");
	}
	   System.out.println();
	 
	 int [] evenArray2 = filterEven2(2,6,7,1,5,8,9);
	for (int i = 0; i < evenArray2[evenArray2.length - 1];i++){
	      System.out.print(evenArray2[i]+" "); 
	}
    }
}
