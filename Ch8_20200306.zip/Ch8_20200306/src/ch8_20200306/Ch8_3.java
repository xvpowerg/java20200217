/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch8_20200306;

/**
 *
 * @author xvpow
 */
//為什麼要用方法!
//重複的功能
//行數過多約13~20 上下
import java.util.Scanner;//做輸入的功能
import java.util.Random;//產生亂數的
public class Ch8_3 {
 
    
    static void numberGame(int endNumber){
	//需求 做一個 猜數字遊戲 1~100
	Scanner scan = new Scanner(System.in);	
	Random rand = new Random();
	int pc = rand.nextInt(endNumber)+1;
	//System.out.println(pc);
	int min = 1 ,max = endNumber;
	while(true){
	  System.out.printf("請輸入您要猜的數字:%d~%d:",min,max);
	 int guess = scan.nextInt();//輸入數字  
	    if (guess == pc){
		System.out.println("答對!");
		break;
	    }else if(guess > pc){
		max = guess;
	    }else{
		min = guess;
	    }
	}
    }
    
    static void loopGame(int loopNumber,int endNumber){
	for (int i =1;i <= loopNumber;i++){
	    numberGame(endNumber);
	}
    }
    
    public static void main(String[] args) {
	loopGame(2,10);
	
	
//本週作業
//寫一個方法
//幫我產生一組大樂透號碼 (7個數字)  
//數字區間 1~49
//每組號碼一定要不一樣
//回傳一個長度7的陣列 將7個數字放在陣列內   
//	numberGame(10);
//	numberGame(30);
//        numberGame(100);
	//1 可以 增加猜的次數
	//2 題目可變1~10 1~30 1~100
	//pc=51
	//20
	//20~100
	//80
	//20~80
	//1 ~n
	
    }
    
}
