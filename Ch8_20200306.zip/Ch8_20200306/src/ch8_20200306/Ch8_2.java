/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch8_20200306;

/**
 *
 * @author xvpow
 */
public class Ch8_2 {
     static void test1(short s1){
	
    }
    static void test1(Float f1){
	
    }
    
    //一個以上一定要有一個關鍵可判定的參數
    static void test2(float f1 ,int v2){
	System.out.println("test2 float f1 ,int v2");
    } 
    static void test2(float f1 ,float f2){
	System.out.println("test2 float f1 ,float f2");
    } 
    
    static void test3(float f1,int v2){
	System.out.println("float f1,int v2");
    }
    static void test3(int v1,float f2){
	System.out.println("float v1,float f2");
    }
     static void test4(float f1,int v2){
	System.out.println("float f1,int v2");
    }
    static void test4(int v1,Integer v2){
	System.out.println("int v1,Integer v2");
    }
    static void test5(int v1,int v2,Integer v3){
	System.out.println("int v1,int v2,Integer v3");
    }
     static void test5(int v1,float v2,int v3){
	System.out.println("int v1,float v2,int v3");
    }
    static void test6(int v1,int v2,Integer v3,float f1){
	System.out.println("int v1,int v2,Integer v3 float f1" );
    }
     static void test6(int v1,float v2,int v3,int v4){
	System.out.println("int v1,float v2,int v3,int v4");
    }
     static void test7(int v1,float f1,int v2){

    }
     static void test7(float v1,int v2,int v3){
	
    }
    public static void main(String[] args) {
	//test1(100); //會產生錯誤 因為100是int 會轉成Integer 只能配對到Integer
	test2(20,50);
	//test3(20,50); 因為模稜兩可所以錯誤
	test4(20,50);//因為20 與 50 皆為基本型態所以選float f1,int v2 
	test5(1,5,6);
	test6(1,2,3,3.5f);
	//test7(1,2,3); //因為模稜兩可所以錯誤
    }
    
}
