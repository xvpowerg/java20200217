/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch4_20200224;

/**
 *
 * @author xvpow
 */
public class Ch4_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
	 
	/*for (  int i =1,  k=1 ; i<=5; i++,k++){
	      System.out.print(k+" ");
	}
	System.out.println(i);//會錯誤 因為i宣告在for內*/
	
	/*int i =1;
	for ( int k=1 ; i<=5; i++,k++){
	      System.out.print(k+" ");
	}
	System.out.println(i);*/

	int k = 0;
	for (int y  =1; y<=3 && ++k <3  ;y++){
	  System.out.print(y+" ");
	}
	 System.out.println(k);
	 //1 k =0 y = 1 
	 //2 y = 1 k = 1
	 //3 pr 1
	 //4 y = 2 
	 //5 y = 2 k = 2
	 //6 pr 2
	 //7 y = 3
	 //8 y = 3 k = 3
	 //9 pr = 3
	 // 10 y = 4
	 
       /* int h = 0;
	for (int y  =1; y<=3 || h++ <3  ;y++){
	  System.out.print(y);
	}
	 System.out.println(h);*/
	 //1 h = 0 y = 1
	 //2 y=1 h = 0
	 //3 y = 2 h =0
	 //4 y = 3 h =0
	 //5 y = 4 h = 1
	 //6 y = 5 h = 2
	 //7 y = 6 h = 3
	 //8 y = 7 h = 4

    }
    
}
