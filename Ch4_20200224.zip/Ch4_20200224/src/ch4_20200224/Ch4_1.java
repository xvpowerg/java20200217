/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch4_20200224;

/**
 *
 * @author xvpow
 */
public class Ch4_1 {

    public static void main(String[] args) {
//	    String st1 = "Ken";
//	    String st2 = "Ken";
//	    System.out.println(st2.equals(st1)  );
//	    String st3= new String("Ken");
//	 System.out.println(st3 == st1  );
	
	// String name = new String("Ken");//正常版
	String name = null;// java.lang.NullPointerException 
	final String KEN = "Ken";
	 switch(name){
	     case KEN:
		 System.out.println("高級工程師");
		 break;
	     case "Vivin":
		 System.out.println("業務");
		 break;
	     case "Lindy":
		  System.out.println("秘書");
		 break;
	     default:
		 System.out.println("錯誤!");
		 break;
	 }
	 
	 
	  //null 空無一物
	  String msg = null;
	//  msg = "你好!";
	  
	  //if (msg != null){
	       System.out.println(msg.equals("你好!"));
	 // }
	
    }
    
}
