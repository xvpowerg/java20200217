      /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch4_20200224;

/**
 *
 * @author xvpow
 */
public class Ch4_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
	int k = 3;
	for (int i =1; i<= 5; i++,k--){
	    if (k < 2){
		//break;
		continue;
	    }
	    System.out.println(i);
	}
	 System.out.println(k);
	// 1 k = 3 i = 1
	// 2 pr:1
	//3 i =2 k =2
        //4 pr : 2
	//5 i = 3 k = 1
	// pr : 1
	
	
    }
    
}
