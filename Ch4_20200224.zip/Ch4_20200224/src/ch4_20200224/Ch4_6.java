/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch4_20200224;

/**
 *
 * @author xvpow
 */
public class Ch4_6 {

    public static void main(String[] args) {
	//基本版
//	for (int i =1 ; i <= 5; i++ ){
//	    for (int k = 3 ; k > 0  ; k--){
//		System.out.print(i+"_"+k+" ");
//	    }
//	    System.out.println();
//	}
//沒加上標籤的break 與　continue
//	for (int i =1 ; i <= 5; i++ ){
//	    System.out.println("Star:"+i);
//	    for (int k = 3 ; k > 0  ; k--){
//		//break 跳離迴圈！
//		//continue 繼續下次迴圈！
//		if (i==2){
//		    break;
//		   //System.out.println("continue:"+i+"_"+k);
//		    //continue;
//		}
//		System.out.print(i+"_"+k+" ");
//	    }
//	    System.out.println();	  
//	    System.out.println("End:"+i);
//	}


//加上標籤的break 與　continue
	 tag:
	for (int i =1 ; i <= 5; i++ ){
	    System.out.println("Star:"+i);
	    
	    for (int k = 3 ; k > 0  ; k--){
		//break 跳離tag的迴圈！
		//continue 繼續下次tag的迴圈！
		if (i==2){
		    break tag;
		   //System.out.println("continue:"+i+"_"+k);
		   //continue tag;
		}
		System.out.print(i+"_"+k+" ");
	    }
	    System.out.println();	  
	    System.out.println("End:"+i);
	}


	
    }
    
}
