/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch4_20200224;

/**
 *
 * @author xvpow
 */
public class Ch4_4 {

  
    public static void main(String[] args) {
	
	//一定會執行一次
	//do while 一定要加分號
	int i = 1;
	int sum = 0;
	do{
	  sum += i;   
	  System.out.print(i);
	 if (i != 4) System.out.print("+");
	}while(i++ < 4);
	System.out.println("="+sum);
	//1 sum = 0 i = 1
	//2 sum =1 
	//3 prt:1
	//4 prt:+
	//5 i = 2
	//6 sum = 1 + 2
	
    }
    
}
