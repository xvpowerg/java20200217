/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch4_20200224;

/**
 *
 * @author xvpow
 */
public class Ch4_5 {

  
    public static void main(String[] args) {
	int i =1;
	
	while(i > 10){
	    System.out.println("while!!!");
	}
	//一定執行一次
	do{
	    System.out.println("do while!!!");   
	}while(i > 10);
	
	
    }
    
}
