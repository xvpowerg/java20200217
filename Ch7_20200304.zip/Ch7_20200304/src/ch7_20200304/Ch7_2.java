/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch7_20200304;

/**
 *
 * @author xvpow
 */
public class Ch7_2 {
    //討論 變數放到方法後 是否有機會被改變
    //call by value 一定不會
    //call by value 所有基本型太都是call by value
    //兩數交換
      static void swapInt(int a,int b){
	  int tmp = b;
	  b = a;
	 a = tmp;
      }
      //call by Refernce
      //call by Refernce 可會
    static void swapArray(int[] array){
	 int tmp = array[0];
	 array[0] = array[1];
	 array[1] = tmp;
    }
    public static void main(String[] args) {
	int a = 10;
	int b = 5;
	//%d 整數 %s 字串 %f 浮點數 %n 斷行
	System.out.printf("a:%d b:%d%n",a,b);
	swapInt(a,b);
	System.out.printf("a:%d b:%d %n",a,b);
	
	int[] array = {5,9};
	System.out.printf("array[0]:%d array[1]:%d%n",array[0],array[1]);
	swapArray(array);
	System.out.printf("array[0]:%d array[1]:%d%n",array[0],array[1]);
    }
    
}
