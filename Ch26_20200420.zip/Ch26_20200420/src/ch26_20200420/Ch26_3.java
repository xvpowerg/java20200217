/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch26_20200420;

import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;
import java.util.concurrent.TimeUnit;

/**
 *
 * @author xvpow
 */
public class Ch26_3 {
    static String img = "叉燒包";
    static CyclicBarrier cb = new CyclicBarrier(2);
	static Thread t1 = new Thread(()->{
		System.out.println("下載中....");
		try{
		     TimeUnit.SECONDS.sleep(3);
		     img = "圖片!";
		     cb.await();
		}catch(InterruptedException|BrokenBarrierException ex){ }
		System.out.println("下載完畢....");
	});
    static Thread t2 = new Thread(()->{
	try{
	     cb.await();
	     System.out.println(img);  
	}catch(InterruptedException | BrokenBarrierException ex){
	}
	    });
    
    public static void main(String[] args) {
	
	t2.start();
	t1.start();
	
    }
    
}
