/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch26_20200420;
import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.TimeUnit;
public class Ch26_4 {

    public static void main(String[] args) {
	System.out.println("Start!!!!");
	ExecutorService es = Executors.newCachedThreadPool();
//	es.submit(()->{
//	   for (int i =1;i<=5;i++){
//	       System.out.println(i);
//	       try{
//		 TimeUnit.SECONDS.sleep(1);   
//	       }catch(Exception ex){}
//	   } 
//	});
	
	for (int i =1;i<=1000;i++){
	    es.submit(()->{ 
		String name = Thread.currentThread().getName();
		System.out.println(name);
	    });
	}

	System.out.println("End!!!!");
		
    }
    
}
