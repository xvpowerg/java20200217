/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch26_20200420;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.Future;
public class Ch26_5 {

    public static void main(String[] args) {
	ExecutorService es = Executors.newFixedThreadPool(3);
	//ThreadLocalRandom 執行序專用的Random 他是Thread safe
//	for (int i  =1;i<=100;i++){
//	    es.submit(()->{
//	    System.out.println(Thread.currentThread().getName());
//	    });
//	}
	//es.shutdown();//等所有工作完成才shutdown
	//es.shutdownNow();//shutdownNow 立刻shutdown
	
	Future<Integer> f1 = es.submit(()->{
	    System.out.println("計算中!!...");
	    TimeUnit.SECONDS.sleep(3);
	   return  ThreadLocalRandom.current().nextInt(500);
	});
	es.submit(()->{
	    try{
		 System.out.println("計算完成的數字:"+f1.get());
	    }catch(Exception ex){
	    }
	});
	
	es.shutdown();
	
    }
    
}
