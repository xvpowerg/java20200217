/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch26_20200420.db;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
public class Ch26_6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
	//                  資料庫連線      SQL命令	查詢結果
	//DriverManager --> Connection --> Statement --> ResultSet
	String url = "jdbc:derby://localhost:1527/mydb";
	String name="qwer";
	String pass="123456";
	try(Connection conn = DriverManager.getConnection(url,name,pass);){
	    Statement stm = conn.createStatement();
	    String sql = "INSERT INTO USERINFO(id,name,point) VALUES(%d,'%s',%d)";
	    sql = String.format(sql, 
		    new java.util.Random().nextInt(1000),
		    "Vivin",200);
	    int count = stm.
		  executeUpdate(sql);
	   ResultSet res =  stm.executeQuery("SELECT * FROM USERINFO");
	    while (res.next()){
		System.out.println("id:"+res.getInt(1));
		System.out.println("name:"+res.getString(2));
		System.out.println("point:"+res.getInt("point"));
		System.out.println("==================");
	    }
	}catch(SQLException ex){
	    System.out.println(ex);
	}
	
    }
    
}
