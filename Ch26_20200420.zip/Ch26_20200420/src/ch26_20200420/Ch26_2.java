/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch26_20200420;

/**
 *
 * @author xvpow
 */
public class Ch26_2 {
    static class TestLock{
	public synchronized void test1(TestLock tLock){
	    System.out.println("name1:"+Thread.currentThread().getName());
	    tLock.test2();
	}
	
	public synchronized void test2(){
	   System.out.println("name2:"+Thread.currentThread().getName());
	    System.out.println("test2!!");
	}
    }
  
    public static void main(String[] args) {
	    //Lock
    //飢餓鎖starvation Lock   優先子(Priority)
    // 如果有一隻執行續很久都無法運行(權重過低)就是飢餓鎖
    //活鎖livelock   有互斥現象
    // 假設我觸了開啟事件又不小心觸發關閉事件 
    //死鎖 deadlock 文章中比較多Thread
     //1 一個以上的執行續
    //2 一定有資源共享(synchronized)
    TestLock testLock1 = new TestLock();
    TestLock testLock2 = new TestLock(); 
    Thread t1 = new Thread(()->testLock1.test1(testLock2));
    Thread t2 = new Thread(()-> testLock2.test1(testLock1) );
    t1.start();
   t2.start();
   
    
    
    }
    
}
