/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch21_20200408;
import java.util.function.Consumer;
import java.util.stream.Stream;
import java.util.stream.IntStream;
import java.util.stream.LongStream;
import java.util.stream.DoubleStream;
import java.util.ArrayList;
import java.util.List;
public class Ch21_5 {

  
    public static void main(String[] args) {
	List<String> list = new ArrayList<>();
	list.add("Apple");
	list.add("Charry");
	list.add("Banana");
	list.add("KiWi");
	//跑內部迴圈
	//list.stream().filter(f->f.length() > 5).forEach(System.out::println);
	Stream<String> str =  Stream.of("Apple","Charry","Banana");
	 long count =  str.count();
	 System.out.println(count);
	 MyNumber n1 = new MyNumber(30);
	  MyNumber n2 = new MyNumber(15);
	  MyNumber n3 = new MyNumber(21);
	  MyNumber[] array = {n1,n2,n3};
	  //? super MyNumber  可以傳入 MyNumber類型 或是MyNumber的父類型 
	  Consumer<Object> c1 = (n)->System.out.print(n+" ");//可傳入forEach
	 Consumer<MyNumber> c2 = (n)->System.out.print(n+" ");//可傳入forEach
	 Stream.of(array).forEach(c2);
	 
    }
    
}
