/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch21_20200408;
import java.util.TreeMap;
import java.util.Comparator;
public class Ch21_2 {
    public static void main(String[] args) {
	
	TreeMap<Integer,String> treeMap = new TreeMap<>();
	//用KEY排序
	treeMap.put(87, "Ken");
	treeMap.put(62, "Iris");
	treeMap.put(95, "Lindy");
	treeMap.put(71, "Sean");
	treeMap.put(32, "Tom");
	//System.out.println(treeMap);
	Comparator<MyNumber> ctor =  Comparator.
			    <MyNumber,Integer>comparing(n->n.getNumber());
	ctor = ctor.reversed();
	TreeMap<MyNumber,String> treeMap2 = new TreeMap<>(ctor);
	MyNumber n1 = new MyNumber(50);
	MyNumber n2 = new MyNumber(25);
	MyNumber n3 = new MyNumber(71);
	MyNumber n4 = new MyNumber(83);
	MyNumber n5 = new MyNumber(17);
	
	treeMap2.put(n1, "Ken");
	treeMap2.put(n2, "Iris");
	treeMap2.put(n3, "Lindy");
	treeMap2.put(n4, "Sean");
	treeMap2.put(n5, "Tom");
	
	System.out.println(treeMap2);
	
    }
    
}
