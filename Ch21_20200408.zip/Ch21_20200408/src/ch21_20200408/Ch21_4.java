/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch21_20200408;

interface Filter<T>{
    boolean filter(T f);
}


public class Ch21_4 {
    static void listName(Filter<String> f,String... names  ){
	    for (String n : names){
		if (f.filter(n)){
		    System.out.println(n);
		}
	    }  
    }
    //會自動判斷類型
        static <T>void listAge(Filter<T> f,T... names  ){
	    for (T n : names){
		if (f.filter(n)){
		    System.out.println(n);
		}
	    }
    }
    public static void main(String[] args) {
	listName(s->s.length() > 3,"Ken","Lindy","Vivin","Lucy","Tom");
	listAge(a->a>=18,10,18,30,20); //會自動判斷類型
    }
}
