/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch21_20200408;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;
import java.util.stream.IntStream;
import java.util.Random;
public class Ch21_6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
//	 MyNumber n1 = new MyNumber(30);
//	  MyNumber n2 = new MyNumber(15);
//	  MyNumber n3 = new MyNumber(21);
//	  List<MyNumber> myList = new ArrayList<>();
//	  myList.add(n1);
//	  myList.add(n2);
//	  myList.add(n3);
//	Stream.of(myList).forEach(System.out::println);
	
	Stream str = Stream.generate(()->new Random().nextInt(50000)).limit(5);
	str.forEach(System.out::println);
	Stream.iterate(2, n->n+1).limit(5).forEach(System.out::println);
	
    }
    
}
