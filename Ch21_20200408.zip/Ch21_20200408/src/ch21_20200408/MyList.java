/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch21_20200408;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
public class  MyList<T> {
    private List<T> myList = new ArrayList<>();
    
    public void add(T  v){
	myList.add(v);
    }
    public T get(int index){
	return myList.get(index);
    }
    public void foreach(Consumer<T> consumer){
	myList.forEach(consumer);
    }
    
    public static<U>  List<U>  toList(U... values){
	List<U> myList = new ArrayList<>();
	for (U v : values){
	    myList.add(v);
	}
	return myList;
    }
}
