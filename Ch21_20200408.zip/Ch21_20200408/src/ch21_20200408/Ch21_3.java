/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch21_20200408;

import java.util.List;

/**
 *
 * @author xvpow
 */
public class Ch21_3 {
    public static void main(String[] args) {
	
	MyList myList = new MyList();
	myList.add("Ken");
	myList.add("Lindy");
	myList.add("Iris");
	myList.add("Tom");
	myList.foreach(System.out::println);
	
	MyList<Integer> myList2 = new MyList<>();
	myList2.add(100);
	myList2.add(250);
	System.out.println(myList2.get(0));
	
	List<Integer> myList3 = MyList.toList(90,20,60);//可自動判斷類型
	List<String> myList4 = MyList.toList("Ken","Join","Vivin");
	List<Float> myList5 = MyList.<Float>toList(1.2f,5.6f);//可限定類型
	System.out.println(myList4);
	System.out.println(myList5);
    }
    
}
