/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch21_20200408;

import java.util.HashMap;

/**
 *
 * @author xvpow
 */
public class Ch21_1 {
    
    static void put(HashMap<Integer,String> map,int key,String value){
	String tmp = "";    
	if (map.containsKey(key)){
	    tmp  = map.get(key)+",";
	}
	tmp += value;
	map.put(key, tmp);
    }
    static void put2(HashMap<Integer,String> map,int key,String value){
	map.computeIfPresent(key, (k,o)-> o+","+value);//如果key存在 才呼叫
	map.computeIfAbsent(key, (k)->value);//如果key不存在 才呼叫
    }
    
    public static void main(String[] args) {
	HashMap<Integer,String> map = new HashMap<>();
	map.put(10, "Ken");
	map.put(12, "Vivin");
	map.put(6, "Join");
	map.put(7, "Yumi");
//	put(map,6,"Iris");
//	put(map,10,"Lucy");
	put2(map,6,"Iris");
	put2(map,10,"Lucy");
	put2(map,10,"Ben");
	put2(map,2,"Jack");
	
//	map.computeIfPresent(7, (k,o)->{
//	    System.out.println(k+":"+o);
//	    return k+","+o;
//	});
	System.out.println(map);
    }
}
