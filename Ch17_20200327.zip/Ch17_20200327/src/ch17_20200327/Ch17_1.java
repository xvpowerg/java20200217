/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch17_20200327;

/**
 *
 * @author xvpow
 */
public class Ch17_1 {
       static String toAlphabet(Number n){
	   String result = "";
	    int nInt= n.intValue() ;
	    char c1 = ' ';
	    if (nInt >= 'A' && nInt <= 'Z' || 
		    nInt >= 'a' && nInt <= 'z')c1 =  (char)nInt;
	    result+=c1;
	    return result;
       }
       static String testMap(Map myMap,Number ... n){
	   String tmp = "";
	   for (Number v : n){
	        tmp+=myMap.toMap(v);    
	   }
	   return tmp;
       }
    public static void main(String[] args) {
	
	//1 內部類
	String s1 =  testMap(new Map(){
	       public String toMap(Number n1){
		    return "成績:"+n1+" ";
	       }
	   },56,89,71,92.5);
	System.out.println(s1);
	
	Map myToMap = new Map(){
                public String toMap(Number n){
		    return "學號:"+n+" ";
		}	
	};
	String s2 = testMap(myToMap,92,30,86,17);
	String s3 = testMap(myToMap,75,63,24,89);
	System.out.println(s2);
	System.out.println(s3);
	
	//lambda 
	String s4 =  testMap( n->{
	    return "年齡:"+n+" ";
	},90,25,81,32,54);
	System.out.println(s4);
	Map myToMap2 = n->"身高:"+n+"cm ";
	String s5 =  testMap(myToMap2,189.2,175,192,155);
	System.out.println(s5);
	//希望可以把傳入的數字轉換成相對應的字元，但如果不是英文字母的 
	//65~90 A~Z
	//97 ~97+25 a~z
	//如果不是以上字元時幫我轉換成空白字元
	String s6 = testMap(n->{
	    String result = "";
	    int nInt= n.intValue() ;
	    char c1 = ' ';
	    if (nInt >= 'A' && nInt <= 'Z' || 
		    nInt >= 'a' && nInt <= 'z')c1 =  (char)nInt;
	    result+=c1;
	    return result;
	},98,66,72,12312,71,65,89);
	System.out.println(s6);
	
	//Method Reference
	String s7 =  testMap(Ch17_1::toAlphabet,77,82,69,84,789,99,120,130);
	System.out.println(s7);
	//因為Map 介面 的方法傳入參數是Number 回傳為String 所以可以使用以下寫法
	//呼叫參數Number的toString
	String s8 =  testMap(Number::toString,77,82,69,84,789,99,120,130);
	System.out.println(s8);
	//數字轉字元
	 //System.out.println((char)(65 +25));
	 // System.out.println((char)(97 + 25));
	 
    }
    
}
