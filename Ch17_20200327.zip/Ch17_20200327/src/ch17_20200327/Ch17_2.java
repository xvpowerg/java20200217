/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch17_20200327;

/**
 *
 * @author xvpow
 */
public class Ch17_2 {

    //遮蔽 Shadow
    //討論 屬性 靜態方法 是誰在執行
    //靜態與屬性 看類別
    //非靜態方法 看物件
    public static void main(String[] args) {
	TestShadow ts = new TestShadowSub();
	ts.test1();//TestShadow test1:10
	ts.test2();//TestShadow test2
	ts.test3();//TestShadowSub test3
	ts.v2 = 189;
	ts.test4();
	ts.test5();

	TestShadowSub ts2 = new TestShadowSub();
	ts2.v3 = 72;
	ts2.test6();
	
	TestShadow ts3 = new TestShadowSub();
	ts3.v4= 188;
	ts3.test7();
	
	TestShadow ts4 = new TestShadowSub();
	ts4.test8();
    }
    
}
