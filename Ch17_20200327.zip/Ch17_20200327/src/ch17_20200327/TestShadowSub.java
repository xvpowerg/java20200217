/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch17_20200327;

/**
 *
 * @author xvpow
 */
public class TestShadowSub extends TestShadow {
       int v2;
       int v3;
       void test3(){
	System.out.println("TestShadowSub test3");
     }
       @Override
       void test4(){
	System.out.println("TestShadowSub test4:"+v2);
    }
       
    static void test5(){
	System.out.println("TestShadowSub test5");
    }
    
     void test7(){
	System.out.println("TestShadowSub test7:"+v4);
    }
     
     static void test8(){
	System.out.println("TestShadowSub test8");
    }
}
