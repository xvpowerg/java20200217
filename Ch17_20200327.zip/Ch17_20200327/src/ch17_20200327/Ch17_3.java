/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch17_20200327;

/**
 *
 * @author xvpow
 */
public class Ch17_3 {

    public static void main(String[] args) {
	
	String s1 = "A";
	String s2 = "B";
	String s3 = "C";
	String s4 = "D";
	//AB
	//ABC
	//ABCD
	String s5 = s1 +s2 + s3 +s4;
	
	StringBuilder sb = new StringBuilder();
	             // index    length
	sb.append("A"); //0       1
	sb.append("B"); //1       2
	sb.append("C"); //2       3
	sb.append("D"); //3       4
	System.out.println(sb);
	sb.delete(1,3);//會移除BC //Start 是填入要刪除的開始索引(index)
	//end 是填入要刪除的結束的長度位置(length)
	System.out.println(sb);
	
	
	
    }
    
}
