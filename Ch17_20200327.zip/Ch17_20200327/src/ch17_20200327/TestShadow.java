/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch17_20200327;

/**
 *
 * @author xvpow
 */
public class TestShadow {
    int v1;
    int v2;
    int v3;
    int v4;
    static int stValue = 10;
    static void test1(){
	System.out.println("TestShadow test1:"+stValue);
    }
    void test2(){
	System.out.println("TestShadow test2");
    }
    void test3(){
	System.out.println("TestShadow test3");
    }
    void test4(){
	System.out.println("TestShadow test4:"+v2);
    }
     static void test5(){
	System.out.println("TestShadow test5");
    }
      void test6(){
	System.out.println("TestShadow test6:"+v3);
    }
    void test7(){
	System.out.println("TestShadow test7:"+v4);
    }
    
    static void test8(){
	System.out.println("TestShadow test8");
    }
}
