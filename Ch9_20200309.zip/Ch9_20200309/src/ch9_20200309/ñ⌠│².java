/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20200309;
public class 水壺 {
    //Attributes or Property 屬性
    int 顏色;
    float 容量;
    String 材質;
    int 耐熱度;
    //Method
    //方法的參數:Parameter
    void print(){
	System.out.printf("顏色:%s 容量: %f 耐熱度:%d 材質:%s %n",
		Integer.toHexString(顏色),
		容量,
		耐熱度,
		材質);
    }
}
