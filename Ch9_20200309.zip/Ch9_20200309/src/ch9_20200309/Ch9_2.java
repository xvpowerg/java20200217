/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20200309;

/**
 *
 * @author xvpow
 */
public class Ch9_2 {
    
    public static void main(String[] args) {
	//物件導向
	//類別　
	// 水壺類別
	
	//顏色　
	//容量　
	//材質
	//耐熱度　
	//由類別創造出物件
	//物件產生點在ｎｅｗ
	水壺 紅色水壺 = new 水壺();
	紅色水壺.顏色 = 0xFB0000;
	紅色水壺.容量 = 500;
	紅色水壺.耐熱度 = 120;
	紅色水壺.材質 = "304不鏽鋼";
	
	水壺 藍色水壺 = new 水壺();
	藍色水壺.顏色 = 0x0000FA;
	藍色水壺.容量 = 600;
	藍色水壺.耐熱度 = 80;
	藍色水壺.材質 = "美奈米";
	
	紅色水壺.print();
	藍色水壺.print();
	
//	System.out.printf("顏色:%s 容量: %f 耐熱度:%d 材質:%s %n",
//		Integer.toHexString(紅色水壺.顏色),
//		紅色水壺.容量,
//		紅色水壺.耐熱度,
//		紅色水壺.材質);
//	System.out.printf("顏色:%s 容量: %f 耐熱度:%d 材質:%s %n",
//		Integer.toHexString(藍色水壺.顏色),
//		藍色水壺.容量,
//		藍色水壺.耐熱度,
//		藍色水壺.材質);
	//藍色水壺 容量 600 耐熱度 80 材質:美奈米 顏色:0000FF
	
	
    }
}
