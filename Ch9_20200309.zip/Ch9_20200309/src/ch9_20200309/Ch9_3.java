/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20200309;

/**
 *
 * @author xvpow
 */
public class Ch9_3 {
    
    public static void main(String[] args) {
	Bird b1 = new Bird();
	b1.name = "崔弟";
	b1.setAge(2);
	b1.setHeight(2000f) ;
	b1.print();
	
	Bird b2 = new Bird();
	b2.name = "";
	b2.setAge(2000);//0~500      
	b2.setHeight(600f);//1~1000
	b2.print();
	//作業:
	// name 我希望長度不要超過5 也 不可全都是空白
	//可用此方法給預設值
	Bird b3 = new Bird("DoDo",6,180);
	b3.print();
	b3.name = "CoCo";
	b3.print();
	Bird b4 = null;
	b4  = new Bird("",1,5);
	b4.name = "Lucy";
	b4.print();
    }
    
}
