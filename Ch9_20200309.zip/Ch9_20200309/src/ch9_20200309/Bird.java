/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20200309;

/**
 *
 * @author xvpow
 */
public class Bird {
    String name;
    //封裝 Encapsulation
    private int age;
    private float height;
    //Constructor 建構式 
    //不會有回傳值
    //方法名稱跟類別一模一樣
     Bird(){
	
    }
    Bird(String inName,int inAge,float inHeight){
	name = inName;
	setAge(inAge);
	setHeight(inHeight);
    }
    //存錢
   public void setAge(int inAge){
       if (inAge < 0 || inAge > 500){
	   System.out.println(name+"錯誤的年齡!");
	   return;
       }
      age = inAge;
   }
   //領錢
   public int getAge(){
       return age;
   }
   
   public void setHeight(float inHeight){
       if (inHeight < 1 || inHeight > 1000){
	   System.out.println(name+"錯誤的身高");
	   return;
       }
       height = inHeight;
   }
   public float getHeight(){
       return height;
   }
    void print(){
   System.out.
   printf("name:%s height:%f age%d %n",
	   name,height,getAge());
    }
    
}
