/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20200309;
import java.util.Random;
import java.util.Arrays;
public class Ch9_1 {
    static boolean existing1(int n,int... array){
	for (int v : array){
	    if (v == n) return true;
	}
	return false;
    }
    
     static boolean existing2(int n,int... array){
	 int[] array2 = Arrays.copyOf(array, array.length);
	   Arrays.sort(array2);
	return Arrays.binarySearch(array2, n) >= 0;
     }
    
    static int[] lotto(){
	int[] lottoArray = new int[7];
	Random ran = new Random();
	for (int i = 0;i<7;){
	   int number = ran.nextInt(49) + 1;
	   if (!existing2(number,lottoArray)){
	        lottoArray[i++] = number; 
	   }
	}
	return lottoArray;
    } 
    
    static void printArray(int... array){
	System.out.println("=======================");
	for (int n : array){
	    System.out.print(n+" ");
	}
	System.out.println();
	System.out.println("=======================");
    }
    
    public static void main(String[] args) {
	 for (int i =1;i<=10;i++){
	  int[] lottoArray = lotto();
	  printArray(lottoArray);
     }
	
	//本週作業
    //寫一個方法
    //幫我產生一組大樂透號碼 (7個數字)  
    //數字區間 1~49
    //每組號碼一定要不一樣
    //回傳一個長度7的陣列 將7個數字放在陣列內   

    
    }
    
}
