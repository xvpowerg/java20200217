/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch13_20200318;

/**
 *
 * @author xvpow
 */
public class TestBlock1 {
    int[] values = new int[50000]; 
    int size = 0;
    //非靜態區塊用於 "每個建構子都需要的屬性" 若需要初始化時 可於區塊內實作
    {
    //早於建構子呼叫
	for (int i= 0;i<values.length;i++){
		values[i] = -1;
	    }
    }
    
    TestBlock1(){ }
    TestBlock1(int size){
	  //this();
	  this.size = size;
      }
    void printArray(){
	for (int i =0;i<5;i++){
	    System.out.print(values[i]+" ");
	}
	 System.out.println();
	  System.out.println("===================");
    }
 

}
