/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch13_20200318;

/**
 *
 * @author xvpow
 */
public class Bird implements Fly{
    public void flying(){
	System.out.println("鳥飛!!");
    }
}
