/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch13_20200318;

/**
 *
 * @author xvpow
 */
public class Ch13_4 {


    static void testFly(Fly fly){
	fly.flying();
    }
    
    public static void main(String[] args) {
	Fly birdFly = new AirPlane();
	birdFly.flying();
	AirPlane airplane = new AirPlane();
	Bird bird = new Bird();
	testFly(airplane);
	testFly(bird);
	
	Run run = airplane;
	run.runing();
    }
    
}
