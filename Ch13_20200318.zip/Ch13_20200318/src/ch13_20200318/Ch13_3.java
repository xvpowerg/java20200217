/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch13_20200318;

/**
 *
 * @author xvpow
 */
public class Ch13_3 {
    
    
    public static void main(String[] args) {
	//抽象類別 與 介面
	//Car car1 = new Car("Toyota",4,6);
	//System.out.println(car1);
	
	Car car2 = new Toyota(4,6);
	System.out.println(car2);
	System.out.println(car2.engine());
    }
    
}
