/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch13_20200318;

/**
 *
 * @author xvpow
 */
public class TestBlock3 {
    //呼叫順序
    //靜態區塊 非靜態區塊 建構子
    //每new一次非靜態區塊就會呼叫一次
    static int value = 10;
    TestBlock3(){
	System.out.println("TestBlock3().......");
    }
    {
    System.out.println("Block 1");
    }
    static{
	//靜態區塊只會呼叫一次
	System.out.println("StaticBlock 1");
    }
    {
    System.out.println("Block 2");
    }
    static{
	System.out.println("StaticBlock 2");
    }
}
