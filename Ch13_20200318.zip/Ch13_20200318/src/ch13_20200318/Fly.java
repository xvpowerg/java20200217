/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch13_20200318;

/**
 *
 * @author xvpow
 */
//interface 一般方法只能是抽象的
//interface 抽象方法只有public
public interface Fly {
    //一般方法預設如下
    //public abstract void flying();
     void flying();
}
