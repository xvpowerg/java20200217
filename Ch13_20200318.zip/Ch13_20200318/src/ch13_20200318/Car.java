/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch13_20200318;

/**
 *
 * @author xvpow
 */
//抽象無法new
//只要有抽象方法類別一定抽象
//final 不可以
//在類別 不可被繼承 
//在方法 不可被複寫
//在變數 不可重新給數值
public abstract  class Car {
    private String company;
    private int wheel;
    private int doorCount;
    Car(String company,int wheel,int doorCount){
	this.company = company;
	this.wheel = wheel;
	this.doorCount = doorCount;
    }
    public abstract String engine();
   public String toString(){
       return this.company+":"+this.wheel+":"+this.doorCount;      
   }
}
