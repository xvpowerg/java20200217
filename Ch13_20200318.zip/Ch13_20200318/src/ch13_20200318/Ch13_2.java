/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch13_20200318;

/**
 *
 * @author xvpow
 */
public class Ch13_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
//	TestBlock3.value = 25;
//	TestBlock3.value = 10;

    TestBlock3 t1 = new TestBlock3();
    TestBlock3 t2 = new TestBlock3();
    }
    
}
