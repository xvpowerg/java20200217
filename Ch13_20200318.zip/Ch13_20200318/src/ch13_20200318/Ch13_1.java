/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch13_20200318;

public class Ch13_1  {
    public static void main(String[] args) {
	// TODO code application logic here
//     TestBlock1 tb1 = new TestBlock1();
//     tb1.printArray();
//     TestBlock1 tb2 = new TestBlock1(50);
//     tb2.printArray();
     
//     TestBlockStatic2 tb3 = new TestBlockStatic2();
//     tb3.printArray();
     //TestBlockStatic2 tb4 = null;
     TestBlockStatic2.printArray();
    }
    
}
