/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch13_20200318;

/**
 *
 * @author xvpow
 */
//繼承了抽象類別 如抽象類別有抽象方法則 必須複寫抽象方法 或把目前類別改為抽象
public  class Benz  extends Car{
    Benz(int wheel,int doorCount ){
	super("Benz",wheel,doorCount);
    }
     public  String engine(){
	 return "電動";
     }
}
