/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch11_20200313;

/**
 *
 * @author xvpow
 */
public class Employee  extends Person{
    @Override  //只能是public
    public void publicMethod(){
	
    }
    @Override //可改成public
     protected void protectedMethod(){
	
    }
    @Override //可改成public or protecrted
     void defaultMethod(){
	
    }
   //不是override 因為private的在子類別根本不存在
    private void privateMethod(){
	
    }
    //不可複寫 回傳為基本型太必須一樣
//    public int getRunTime(){
//	return 2000;
//    }
    //可複寫 因為 Employee繼承了Person
    public Employee getBoss(){
	return null;
    }
}
