/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch11_20200313;

/**
 *
 * @author xvpow
 */
public class Ch11_1 {

    public static void main(String[] args) {

	    Person p1 = new Person();
	   p1.age = 10;
	   p1.name = "Ken";
	   p1.salary = 25000;
	   

    }
    
}
