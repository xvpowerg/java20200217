/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch11_20200313;
import java.io.IOException;
/**
 *
 * @author xvpow
 */
public class Person {
    //複寫規則
    //讀取權限只能開放不能封閉
    //public 不同package也可讀取
    //protected 就算跨package也可在繼承的子類別內使用
    //private 只能自己的類別內讀取 其他在相同package都可讀取
   //一樣 指的是跟父類別一樣
    //回傳值 如果是基本型太必須一樣 如果是類別 可以是子類型或一樣
    //方法名稱要一樣參數也要一樣
    //例外拋出可拋出一樣或子類型 或不拋出
    public int age;
    protected String name;
    float salary;//稱為預設 default 
    private int phoneNumber;
    
    public void publicMethod(){
	System.out.println("public");
    }
     protected void protectedMethod(){
	System.out.println("protected");
    }
      void defaultMethod(){
	System.out.println("default");
    }
    private void privateMethod(){
	System.out.println("private");
    }
    
    public long getRunTime(){
	return 200000;
    }
    
    public Person getBoss(){
	return null;
    }
    
    public void setAge(int age){
	if (age < 0 || age > 500){
	    System.out.println("錯誤的age");
	    //拋出例外 程式碼會中斷
	    throw new  IllegalArgumentException("錯誤的age");
	}
	this.age = age;
    }
    //throw 我要拋出例外
    //throws 可能會拋出例外
    public void setName(String name)throws IOException {
	if (name == null){
	    throw new IOException("name不可為null");
	}
	this.name =name;
    }
    
    public void setSalary(float salary)throws SalaryException{
	if (salary < 20000){
	    throw new SalaryException();
	}
    }
  public void setPhoneNumber(int phoneNumber){

}
}

//作業
//幫 phoneNumber 寫一個例外
//此例外必須繼承Exception
//setPhoneNumber 如果number 為0  就拋出例外 
//PhoneNumberException