/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch11_20200313;
import java.io.IOException;
/**
 *
 * @author xvpow
 */
public class Ch11_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
	//例外有兩種
	//checked exceptions,
	// 必要例外檢測 強烈提醒會出錯 程式無法處理的
	   //只是直接繼承Exception 除了RuntimeException 外都是必要例外檢測
	   //記:IOException FileNotFoundException是IOException的子類  SQLException  InterruptedException
	//非必要例外檢測  unchecked exceptions 可防可控的
	    //繼承了RuntimeException 
	    // 常用 *NumberFormatException 
	     //IndexOutOfBoundsException ArithmeticException
	    
	try{
	   Person p1 = new Person();
	    p1.setAge(20);
	    System.out.println(p1.age); 
	    p1.setName("AA");
	    p1.setSalary(1500);
	}catch(IllegalArgumentException ex){
	    System.out.println("Error Msg:"+ex);
	}catch(IOException ex){
	     System.out.println("Error Msg:"+ex);
	}
	System.out.println("End");

		
		
	
    }
    
}
