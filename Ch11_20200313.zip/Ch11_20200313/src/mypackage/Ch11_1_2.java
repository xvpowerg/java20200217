/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mypackage;
import ch11_20200313.Person;
public class Ch11_1_2 {

  
    public static void main(String[] args) {
	//跨不同package必須import
	   Person p2 = new Person();
	  p2.age = 10;
	
	
	
    }
    
}
