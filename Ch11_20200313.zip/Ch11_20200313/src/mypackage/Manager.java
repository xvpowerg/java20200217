/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mypackage;
import ch11_20200313.Person;

public class Manager extends Person {
    private void test(){
	System.out.println(this.name);
    }
    
       @Override  //只能是public
    public void publicMethod(){
	
    }
   // @Override //可改成public
      protected void protectedMethod(){
	
    }
    //@Override  //default跨package無法複寫
     void defaultMethod(){
	
    }
    
}
