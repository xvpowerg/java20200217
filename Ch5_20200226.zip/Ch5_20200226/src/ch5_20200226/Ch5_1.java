/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20200226;

/**
 *
 * @author xvpow
 */
import java.util.stream.IntStream;
public class Ch5_1 {
    public static void main(String[] args) {
	//正常情況下
	int[] scores = new int[5];//陣列長度是5
	scores[1] = 72;
	scores[3] = 81;
	scores[4] = 95;
	System.out.println(scores[3]);
	System.out.println(scores[2]);
	//陣列預設內容
	//整數陣列的內容 預設為0
	//浮點數 預設的內容為 0.0
	//字元 預設的內容為 空白字元
	//Boolean 預設的內容為 false
	//其他 預設的內容為  null
	System.out.println("=========================");
	//第一種 取得數值的方式 
	/*for (int i = 0; i < scores.length ;i++){
	    System.out.println(i+":"+scores[i]);
	}*/
	//第2種 取得數值的方式  名稱:foreach
	// 一輪巡 
	/*int i =0;
	for (int v : scores){
	    System.out.println(i++ +":"+v);
	}*/
	//第3種 使用IntStream 無法取得索引值
	IntStream.of(scores).
		forEach(System.out::println);
	
	
    }
    
}
