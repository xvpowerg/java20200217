/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20200226;

/**
 *
 * @author xvpow
 */
public class Ch5_2 {

    //一維陣列考試重點
    public static void main(String[] args) {
	//宣告方式變化
	int[] array1 = new int[3];//* Java愛
	int array2[] = new int[3];
	//給數值值的變化方式
	boolean[] array3 = new boolean[3];
	boolean[] array4 = {true,false,true};
	//String[] array5 = new String[3]{"Ken","Vivin","Lindy"};//錯誤的 因為加上了陣列長度
	String[] array5 = new String[]{"Ken","Vivin","Lindy"};//超愛考!!
	
	// 這類語法"{1,5,7,8}" 只能用在宣告
	int[] array6 = {1,5,7,8};
	//array6 = {1,5,7,8,2,5,9};//錯誤因為沒用在宣告
	//new int[]{1,5,7,8,2,5,9}; 可用在宣告 與 重新賦予值
	array6 = new int[]{1,5,7,8,2,5,9};
	
    }
    
}
