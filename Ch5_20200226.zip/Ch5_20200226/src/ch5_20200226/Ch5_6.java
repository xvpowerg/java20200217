/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20200226;

/**
 *
 * @author xvpow
 */
public class Ch5_6 {
    public static void main(String[] args) {
	//多維陣列
	 int[][] array2x3 = new int[2][3];
	array2x3[0][1] = 81;
	array2x3[1][0] = 93;
	array2x3[1][2] = 74;
	for (int ri = 0;ri <array2x3.length ;ri++){
	      for (int ci=0;ci < array2x3[ri].length;ci++){
		  System.out.print(array2x3[ri][ci]+" ");
	      }
	      System.out.println();
	}
    }
    //1 Ch5_6 使用foreach 跑一次
    //2 宣告一個長度為20的陣列 幫我把20個陣列內容填滿，
       //內容是1~100中的偶數 如果超過陣列數就不存
}
