/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20200226;
import java.util.Arrays;
public class Ch5_3 {
    //Arrays 必考題!!!
    public static void main(String[] args) {
	//Sort //預設由小到大排序
	int[] array1 = {5,7,8,1,3};
	//快速排序法
	//時間複雜度 簡單來說就是次數 O(nlog2n)，最差為O(n^2)
	//預設由小到大(遞增排序(ASC))
	Arrays.sort(array1);
	for (int v : array1){
	    System.out.print(v+" ");
	}
	System.out.println();
	System.out.println("============字串比較1==============");
	//字串排序 比較大小 使用字元去比
	//數字 < 大寫 < 小寫 < 繁體中文
	String[] array2 = {"c","A","b","G"};
	Arrays.sort(array2);
	for (String s : array2){
	    System.out.print(s +" ");
	}
	System.out.println();
	System.out.println("============字串比較2==============");
	//1 一個字元一個字元比較
	//2 字元都一樣 長的大
	String[] array3 = {"Iris","Kyn","Ken","Apple","Qooo","Qoo"};
	Arrays.sort(array3);
	for (String s : array3){
	    System.out.println(s);
	}
	
    }
    
}
