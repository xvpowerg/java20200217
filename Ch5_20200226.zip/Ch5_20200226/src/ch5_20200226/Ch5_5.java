/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20200226;
import java.util.Arrays;
public class Ch5_5 {

   
    public static void main(String[] args) {
	String[] names = {"C","B","E","G"};
	Arrays.sort(names);
	for (String s : names){
	    System.out.print(s+" ");
	}
	 System.out.println();
	 //比所有都大
	int index =  Arrays.binarySearch(names, "K");
	System.out.println(index);
	//比所有都小
	index = Arrays.binarySearch(names, "A");
	System.out.println(index);
	//在中間
	index = Arrays.binarySearch(names, "D");
	System.out.println(index);
    }
    
}
