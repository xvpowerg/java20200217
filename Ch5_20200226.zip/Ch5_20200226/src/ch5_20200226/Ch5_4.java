/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20200226;

import java.util.Arrays;
public class Ch5_4 {
    public static void main(String[] args) {
	
	//數字 Search
	int[] array = {5,11,9,3,18,7};
	Arrays.sort(array);
	for (int v :array ){
	    System.out.print(v+" ");
	}
	System.out.println();
	//3 5 7 9 11
	//Binary Search 
	//一定要先排序 順序必須由小到大
	int index = Arrays.binarySearch(array, 3);
	System.out.println("index:"+index);
	
	//找不到情況有三種
	//1 比所有數都小 一定回傳-1
	index = Arrays.binarySearch(array, 2);
	System.out.println("index:"+index);
	//2 比所有數都大 (長度 + 1) *-1
	index = Arrays.binarySearch(array, 20);
	System.out.println("index:"+index);
	//3 在數的中間 找到比x大一點數值的長度 * -1
	int x = 10;
	index = Arrays.binarySearch(array, x);
	System.out.println("index:"+index);
    }
    
}
