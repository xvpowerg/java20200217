/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ironman.test;

/**
 *
 * @author xvpow
 */
//可以當成一個介面群組
//介面與介面的關係是extends 介面與類別的關係是implements
public interface IromManSkill extends Attacks,Fly,Moving {
    
}
