/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ironman.test;

/**
 *
 * @author xvpow
 */
public interface Fly {
    int max = 9000;
    void flying(int speed);
    static void checkSpeed(int speed){
	if (speed <0 || speed > max){
	    throw new IllegalArgumentException("錯誤的速度!");
	}
    }
}
