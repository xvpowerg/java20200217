/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ironman.test;

/**
 *
 * @author xvpow
 */
public interface Moving {
    //在介面內所有屬性皆為 公開 靜態 的 常數
    //public static final
    int RUN = 1,WALK = 2,JUMP = 3;
    default void action(int actionType){
	switch(actionType){
	    case Moving.JUMP:
		System.out.println("JUMP!!!");
		break;
	    case Moving.RUN:
		System.out.println("RUN!!!");
		break;
	    case Moving.WALK:
		System.out.println("WALK!!!");
		break;
	}
    }
}
