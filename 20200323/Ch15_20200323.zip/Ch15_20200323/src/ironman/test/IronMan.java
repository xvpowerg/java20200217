/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ironman.test;

/**
 *
 * @author xvpow
 */
public class IronMan implements IromManSkill  {

    @Override
    public void attacking(Object obj) {
	    
    }

    @Override
    public void flying(int speed) {
	Fly.checkSpeed(speed);
	System.out.println("加速到:"+speed);
    }

  
}
