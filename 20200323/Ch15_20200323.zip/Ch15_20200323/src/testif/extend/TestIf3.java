/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testif.extend;

/**
 *
 * @author xvpow
 */
//如果TestIf2 有 extends TestIf1 且複寫了 相同名稱的default方法
//則不會錯誤
public interface TestIf3  extends TestIf1,TestIf2{
     
}
