/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch15_20200323;

/**
 *
 * @author xvpow
 */
//FunctionalInterface 就是 介面中只有一個抽象方法
//用介面模擬方法
//可用@FunctionalInterface 檢查是否為FunctionalInterface
@FunctionalInterface
public interface TestFI {
    void max(int v1);
}
