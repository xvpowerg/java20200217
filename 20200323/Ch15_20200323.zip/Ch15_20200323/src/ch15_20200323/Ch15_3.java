/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch15_20200323;

/**
 *
 * @author xvpow
 */
public class Ch15_3 {

    public static void main(String[] args) {
	MyInterface1 myif1 = new MyClass1();
	myif1.testDefaultMethod();
    }
    
}
