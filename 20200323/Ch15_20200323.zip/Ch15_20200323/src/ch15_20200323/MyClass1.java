/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch15_20200323;

import static ch15_20200323.MyInterface2.testStaticMethod;

/**
 *
 * @author xvpow
 */

//介面有相同default方法 類別在implements 會出現Error
//所以解決方法是 1 複寫default method 或 不要有重複的default
public class MyClass1 implements MyInterface1,MyInterface2{
    @Override
    public void testMethod1() {
	System.out.println("MyClass1!!!");
    }
    
    public void testDefaultMethod(){
	testMethod1();
	MyInterface2.testStaticMethod();
    }
}
