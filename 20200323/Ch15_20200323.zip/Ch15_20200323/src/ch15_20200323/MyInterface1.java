/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch15_20200323;

/**
 *
 * @author xvpow
 */
public interface MyInterface1 {
    void testMethod1();
    //非靜態可以呼叫非靜態 也可以呼叫靜態的
    default void testDefaultMethod(){
	testMethod1();
	testStaticMethod();
    }
     //靜態只可呼叫靜態的
    static void testStaticMethod(){
	//testMethod1();
	//testDefaultMethod();
	System.out.println("testStaticMethod MyInterface1");
    }
}
