/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch15_20200323;
//介面有相同default方法 介面在extends 會出現Error
//所以解決方法是 1 複寫default method 或 不要有重複的default
public interface MyInterface3  extends MyInterface1,MyInterface2 {
       void testMethod1();
       //複寫才會對
    default void testDefaultMethod(){
	testMethod1();
	testStaticMethod();
    }
    static void testStaticMethod(){
	System.out.println("testStaticMethod MyInterface3");
    }
}
