/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch14_20200320;
import java.io.IOException;
import com.read.ReaderData;
public class Ch14_1 {

   //有部份知道怎麼做
    //有部份完成實才知道怎麼做
    public static void main(String[] args)throws IOException {
	//讀資料公司
	//專門輸出
	//ReaderData ex = new ExportReadData();
	//求平均值
	ReaderData ex = new ExportAvgData();
	ex.exportData();
    }
    
    //希望輸出 業績平均值
}
