/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch14_20200320;

import com.read.ReaderData;

/**
 *
 * @author xvpow
 */
public class ExportAvgData extends ReaderData {
     protected void dataStyle(String[] data){
	 for (String detail :  data){
	   String[] tmp = detail.split(",");
	   String name =  tmp[0];
	   float spiSum = 0;
	   for (int i = 1; i < tmp.length ;i++){
	      int kpi =  Integer.parseInt(tmp[i]);
	      spiSum += kpi;
	   }
	   float avg = spiSum / 3;
	   System.out.printf("name:%s avg:%.2f %n",name,avg);
	 }
     }
}
