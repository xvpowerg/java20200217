/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch14_20200320;
import com.read.ReaderData;

public class ExportReadData  extends ReaderData{
    protected void dataStyle(String[] data){
	for (String d : data){
	    //System.out.println(d);
	  String[] strs=  d.split(",");
	  System.out.printf("姓名:%s 第一季%s績效 第二季%s績效 第三季%s績效%n",
		  strs[0],strs[1],strs[2],strs[3]);
	}
	
    }
}
