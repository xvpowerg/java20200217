/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch14_20200320;

/**
 *
 * @author xvpow
 */
public class Ch14_2 {
    
    public static void main(String[] args) {
	 String str = "iphone";
	 CellPhone p1 = null;
	switch(str){
	    case "android":
		p1 = new AndroidPhone();
	    break;
	    case "iphone":
	      p1 = new IPhone();
	     break;  
	}
	p1.callout("7555967");
	p1.wifi();
    }
    
}
